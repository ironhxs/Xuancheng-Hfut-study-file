//
//  main.cpp
//  第五次作业
//
//  Created by 贺鑫帅 on 2023/11/6.
//
////4-9
//#include <iostream>
//#include<cmath>
//using namespace std;
//class dot{
//public:
//    int x;
//    int y;
//};
//class  R_ectangle{
//public:
//    dot a;
//    dot b;
//    int s(){
//        int s_2=0;
//        s_2=abs(a.x-b.x)*abs(a.y-b.y);
//        return s_2;
//    }
//};
//int main() {
//    R_ectangle A;
//    cout<<"请分别输入矩形的左下角与右上角两个点的横纵坐标\n";
//    cin>>A.a.x;
//    cin>>A.a.y;
//    cin>>A.b.x;
//    cin>>A.b.y;
//    cout<<A.s()<<endl;
//    return 0;
//}
//4-10
#include <iostream>
using namespace std;
class date{
public:
    int year,month,day;
};
class person{
public:
    int NO,ID;
    string gender;
    date birth;
    person(int a,int b,string c){
        NO=a;
        ID=b;
        gender=c;
    }
    inline void get() {
        cout<<NO<<' '<<gender<<' '<<birth.year<<' '<<birth.month<<' '<<birth.day<<' '<<ID<<endl;
    }
    
};
using namespace std;
int main() {
   
        
    return 0;
}
//
//
//4-14
//#include <iostream>
//using namespace std;
//class  Tree{
//    int ages;
//public:
//    void grow(int years){
//        ages+=years;
//    }
//    void age(){
//        cout<<ages;
//    }
//    
//};
//
////4-20
//#include <iostream>
//using namespace std;
//class Complex{
//public:
//    Complex(double i,double j):real(i),fake(j){}
//    double real,fake;
//    void show(){
//        cout<<real<<'+'<<fake<<'i'<<endl;
//    }
//    void add(Complex b){
//        real+=b.real;
//        fake+=b.fake;
//    }
//};
//
//int main() {
//    Complex c1(3,5);
//    Complex c2(4.5,0.0);
//    c1.add(c2);
//    c1.show();
//    return 0;
//}


