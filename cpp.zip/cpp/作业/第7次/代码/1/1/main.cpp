//
//  main.cpp
//  1
//
//  Created by 贺鑫帅 on 2023/12/2.
//

//8-8
//#include <iostream>
//using namespace std;
//class BaseClass{
//public:
//    virtual void fn1(){
//        cout<<"this is bcfn1\n";
//    }
//    void fn2(){
//        cout<<"this is bcfn2\n";
//    }
//    
//};
//class DerivedClass:public BaseClass{
//public:
//     void fn1(){
//        cout<<"this is dcfn1\n";
//    }
//    void fn2(){
//        cout<<"this is dcfn2\n";
//    }
//    
//};
//
//int main() {
//    DerivedClass a;
//    DerivedClass *p=&a;
//    BaseClass *q=&a;
//    p->fn1();
//    p->fn2();
//    q->fn1();
//    q->fn2();
//    return 0;
//}

////8-9
//#include <iostream>
//using namespace std;
//class BaseClass{
//public:
//    virtual ~BaseClass(){
//        cout<<"这是基类的析构函数\n";
//    }
//};
//class DerivedClass:public BaseClass{
//public:
//    
//};
//
//int main() {
//    BaseClass *p=new DerivedClass ;
//    delete p;
//    return 0;
//}

//8-10
#include <iostream>
using namespace std;
class point{
public:
    int x,y;
    point (int a,int b){
        x=a;
        y=b;
    }
    friend point operator +(point a,point b){
        point temp(0,0);
        temp.x=a.x+b.x;
        temp.y=a.y+b.y;
        return temp;
    }
};

int main() {
    point a(3,4),b(5,6),c(0,0);
    c=a+b;
    cout<<'('<<c.x<<','<<c.y<<')'<<endl;
    return 0;
}
