//
//  main.cpp
//  随机点名程序
//

#include <iostream>
#include <stdlib.h>
#include<time.h>
#include <string>
#include <fstream>
using namespace std;
//生成随机数
int Rand() {
    int num1, num2;
    srand((unsigned int) time(0));
    num1= rand() % 46+ 1;
    srand(21);
    num2 = rand() % 10;
    int a[10] = { 0,-2,1,0,0,0,-1,2,3,-3};
    if (num1 > 3 && num1 < 43) {
        return num1 + a[num2];
    }
    else {
        return num1;
    }
}
//链表
struct Student {
    string name;
    Student* next;
};
class Classroom {
public:
    Classroom() : head(NULL) {}
    void loadStudents(const string& filename) {
        ifstream file(filename);
        if (file.is_open()) {
            string name;
            while (file >> name) {
                insertStudent(name);
            }
            file.close();
        } else {

            cout << "无法打开文件" << std::endl;

        }
    }
    void insertStudent(const string& name) {
        Student* newStudent = new Student{ name, NULL };
        if (head == NULL) {
            head = newStudent;
        }
        else {
            Student* current = head;
            while (current->next != NULL) {
                current = current->next;
            }
            current->next = newStudent;
            newStudent->next=NULL;
        }
    }
    string getStudentName(int count) const {
        Student* current = head;
        string _name;
        while (count) {
            count--;
            current = current->next;
        }
        _name = current->name;
        return _name;
    }
    Student* head;
};
////将姓名以char*作为返回值便于图形化见面使用
//char * get(string a,char* b){
//    strcpy(b,a.c_str());
//    return b;
//}
void fir_show_menu() {//菜单
 cout << "********************************************" << endl;
 cout << "*********     欢迎阎王使用三班生死簿！   **********" << endl;
    cout << "*************  看看想干啥吧    *************" << endl;
};
void _show_menu() {//菜单
 cout << "*****************让朕想想🤔*****************" << endl;
 cout << "*************  0. 有急事,先行一步!去也~~~ *************" << endl;
 cout << "*************  1.年底赶业绩,再来一个吧!*************" << endl;
 cout << "*************  2. 看看今天的成果!  *************" << endl;
 cout << "********************************************" << endl;
 cout << endl;
};
void end_show_menu() {//菜单
 cout << "*************  下班喽!猴子来打牌呀!  *************" << endl;
 cout << "********************************************" << endl;
 cout << endl;
};
int main() {
    Classroom _th;
    string a;
    char b [11];
    int _mode=1;
    int no;
    _th.loadStudents("/Users/hexinshuai/Downloads/namelist.txt");
        fstream sfile ("/Users/hexinshuai/Downloads/savenamelist.txt",ios:: out|ios:: in);
    fir_show_menu();
    while(_mode){
        _show_menu();
        cin>>_mode;
        switch(_mode){
//            case 0:
//                sfile.put(';');
//                goto flag;
            case 1:
            {   no =Rand();
                a=_th.getStudentName(no);
                //将点过的名字进行存储
                strcpy(b,a.c_str());
//                strcat(b, " ");
                sfile.write(b,11);
                cout<<"这次的幸运儿是:"<<a<<endl;}
                break;
            case 2:
                cout<<"此前的幸运儿有:"<<endl;
                char c[600];
                sfile.get(c,600,';');
                cout<<c;
                sfile.close();
                sfile.open("/Users/hexinshuai/Downloads/savenamelist.txt",ios:: out|ios:: in);
                    break;
            }
        }
//    flag:
        sfile.close();
    //将存储点过名的学生的名单清空
//    ofstream dfile("/Users/hexinshuai/Downloads/savenamelist.txt");
//    if(!dfile.is_open())
//        cout<<"文件打开失败\n";
//    else
//        dfile<<" ";
//    dfile.close();
    end_show_menu() ;
    return 0;
    }

