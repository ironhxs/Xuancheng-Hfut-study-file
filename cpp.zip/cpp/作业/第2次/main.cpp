////  main.cpp
////  CPP作业
////
////  Created by 贺鑫帅 on 2023/10/11.
////
//
//#include <iostream>
//
//int main() {
//    using namespace std;
//cout << "Menu: A（dd）D(elete） S(ort） Q(uit），elect one：\n";
//    char a = 0;
//    do {
//        cin >> a;
//        if (a=='A') {
//            cout<<" 数据已经增加\n" ;
//            continue;}
//        else if(a=='D') {
//            cout<<  "数据已经删除\n";
//            continue;}
//
//        else if(a=='S') {
//            cout<<  "数据已经排序";
//            continue ;}
//        else
//            break;
//
//    } while (1);
//    return 0;
//}













//#include <iostream>
//#include <cstdlib>
//using namespace std;
//int main() {
//    int a = 0;
//    int b=1;
//    cout<<"Menu:猜数游戏 接下来请输入一个整数（1～100）\n";
//    cin>>b;
//    srand(689);
//    a=1+rand()%100;
//    while(a!=b){
//       if(b<a){
//            cout<<"你输入的值太小了，再试一次吧\n";
//           cin>>b;
//            continue;
//        }
//        if(b>a){
//            cout<<"你输入的值太大了，再试一次吧\n";
//            cin>>b;
//            continue;
//        }
//        
//        
//    }
//    cout<<"恭喜你猜对了 wow！\n";
//    return 0;
//    }


//不清楚有啥区别
//#include <iostream>
//#include <cstdlib>
//using namespace std;
//int main() {
//    int a = 0;
//    int b=1;
//    cout<<"Menu:猜数游戏 接下来请输入一个整数（1～100）\n";
//    cin>>b;
//    srand(689);
//    a=1+rand()%100;
//       do{
//       if(b<a){
//            cout<<"你输入的值太小了，再试一次吧\n";
//           cin>>b;
//            continue;
//        }
//        if(b>a){
//            cout<<"你输入的值太大了，再试一次吧\n";
//            cin>>b;
//            continue;
//        }
//        
//        
//       }while(a!=b);
//    cout<<"恭喜你猜对了 wow！\n";
//    return 0;
//    }



//#include <iostream>
//#include <cstdlib>
//using namespace std;
//int main() {
//    int i=0;
//    int t=0;
//    for(i=1;i<101;i++){
//        int flag=0;
//        for(t=2;t<i;t++){
//            if(i%t==0){
//                flag =1;
//                break;}
//               }
//               
//        if(flag==0){
//        cout<<i<<endl;
//                }
//        else
//        continue ;
//            }
//    return 0;}
        
    
#include <iostream>
using namespace std;

int a (){
    return 0;
}
int main(){
    
    return 0;
}



