//
//  main.cpp
//  第六次作业
//
//  Created by 贺鑫帅 on 2023/11/18.
//
//7-6
//#include <iostream>
//using namespace std;
//class Mammal{
//public:
//    Mammal(){
//        cout<<"constructing for Mammal"<<endl;
//    }
//    ~Mammal(){
//        cout<<"destructing for Mammal\n";
//    }
//};
//class dog:public Mammal{
//public:
//    dog(){
//        cout<<"condtructing dog\n";
//    }
//    ~dog(){
//        cout<<"desructing for dog\n";
//    }
//};
//int main() {
//    dog wang;
//    return 0;
//}


////7-10
//#include <iostream>
//using namespace std;
//class Object {
//public:
//    Object(int a):weight(a){
//        cout<<"constructing for Object\n";
//    }
//    ~Object(){
//        cout<<"destructing for Object\n";
//    }
//    int weight;
//    void setw(int a){
//        weight=a;
//    }
//    void get(){
//        cout<<weight<<endl;
//    }
//};
//class Box:public Object{
//public:
//    int height,width;
//    Box(int a,int b,int c):Object(a),height(b),width(c){
//        cout<<"constructing for Box\n";
//    }
//    ~Box(){
//        cout<<"destructing for Box\n";
//    }
//    void seth(int a){
//        height=a;
//    }
//    void setw(int a){
//        width=a;
//    }
//};
//
//int main() {
//    Box c(3,6,9);
//    cout<<c.weight<<' '<<c.height<<' '<<c.width<<endl;
//    return 0;
//}

// 7-11
#include <iostream>
using namespace std;
class baseclass{
public:
    void fn1(){
        cout<<"这是bassclass的fn1\n";
    }
    void fn2(){
        cout<<"这是bassclass的fn2\n";
    }
};
class derivedclass:public baseclass{
public:
    void fn1(){
        cout<<"这是derived class的fn1\n";
    }
    void fn2(){
        cout<<"这是derived class的fn2\n";
    }
};
int main() {
    derivedclass c;
    c.fn1();
    c.fn2();
    baseclass *p=&c;
    derivedclass *q=&c;
    p->fn1();
    p->fn2();
    q->fn1();
    q->fn2();
    return 0;
}


































