//
//  main.cpp
//  第四次作业
//
//  Created by 贺鑫帅 on 2023/10/29.
//


//6-21
//#include <iostream>
//#include <string.h>
//using namespace std;
//int main() {
////    char arr[100];
//    char a=0;
////    int j=0;
//    cout<<"请输入一句英语语句,且以.结尾\n";
////    cin.get(arr,100);
//    
////    int i=0,s=0;
////    while(arr[i++]!='\0'){
////        if(arr[i]!=' ')
////            s++;
////    }
//    int s=0;
//    while (a!='.') {
//        cin>>a;
//        if ( a!= ' ') {
//            s++;
//        }
//    }
//cout<<"此句中字母个数为"<<s-1<<endl;
//    return 0;
//}
//6-22
//#include <iostream>
//#include<string>
//using namespace std;
//void reverse(string&s,int l ,int r){
//    if (l>=r) {
//        return;
//    }
//    char temp;
//    temp=s[l];
//    s[l]=s[r];
//    s[r]=temp;
//    reverse(s,++l,--r);
//}
//int main() {
//    int i=0,j;
//    string s;
//    cout<<"请输入一个字符串\n";
//    cin>>s;
//    while(s[i++]!='\0');
//    reverse(s,0,i);
//    for (j=0; j<=i; j++) {
//        cout<<s[j]<<' ';
//    }
//        
//    return 0;
//}


//6-23
//#include <iostream>
//using namespace std;
//
//void transposeMatrix(int** matrix, int rows, int cols) {
//    int** transposed = new int*[cols]; // 创建一个新的矩阵用于存储转置后的数据
//    for (int i = 0; i < cols; i++) {
//        transposed[i] = new int[rows];
//    }
//
//    // 执行矩阵转置
//    for (int i = 0; i < rows; i++) {
//        for (int j = 0; j < cols; j++) {
//            transposed[j][i] = matrix[i][j];
//        }
//    }
//
//    // 输出转置后的矩阵
//    cout << "转置后的矩阵:" << endl;
//    for (int i = 0; i < cols; i++) {
//        for (int j = 0; j < rows; j++) {
//            cout << transposed[i][j] << " ";
//        }
//        cout << endl;
//    }
//
//    // 释放动态分配的内存
//    for (int i = 0; i < cols; i++) {
//        delete[] transposed[i];
//    }
//    delete[] transposed;
//}
//
//int main() {
//    int rows, cols;
//
//    cout << "请输入矩阵的行数: ";
//    cin >> rows;
//    cout << "请输入矩阵的列数: ";
//    cin >> cols;
//
//    int** matrix = new int*[rows]; // 创建矩阵
//    for (int i = 0; i < rows; i++) {
//        matrix[i] = new int[cols];
//    }
//
//    // 输入矩阵数据
//    cout << "请输入矩阵的数据:" << endl;
//    for (int i = 0; i < rows; i++) {
//        for (int j = 0; j < cols; j++) {
//            cin >> matrix[i][j];
//        }
//    }
//
//    // 调用矩阵转置函数
//    transposeMatrix(matrix, rows, cols);
//
//    // 释放动态分配的内存
//    for (int i = 0; i < rows; i++) {
//        delete[] matrix[i];
//    }
//    delete[] matrix;
//
//    return 0;
//}
//补充题1 超纲了 vector 删除还没学
//补充题2
//#include <iostream>
//using namespace std;
//void px(int arr[10]){
//    int i,j,temp;
//    for (i=0; i<10; i++) {
//        for (j=0; j<9-i; j++) {
//            if (arr[j]>arr[j+1]) {
//                temp = arr[j+1];
//                arr[j+1]=arr[j];
//                arr[j]=temp;
//            }
//        }
//    }
//}
//void find(int arr[10],int l,int a){
//    int f=0,flag=0;
//    int m=(f+l)/2;
//    while (l-f) {
//        if (a>arr[m])
//            f=m;
//        
//        else if (a<arr[m])
//            l=m;
//        else{
//            flag=1;
//            cout<<"找到了,是第"<<m+1<<"个\n";
//            break;
//        }
//        m=(f+l)/2;
//    }
//    if(flag==0)
//        cout<<"未找到\n";}
//        
//int main() {
//    int arr[10],i;
//    cout<<"请为数组赋10个数\n";
//    for (i=0; i<10; i++) {
//        cin>>arr[i];
//    }
//    px(arr);
//    find(arr, 10, 30);
//    return 0;}
#include <iostream>
using namespace std;

void px(int arr[10]) {
    int i, j, temp;
    for (i = 0; i < 9; i++) {
        for (j = 0; j < 9 - i; j++) {
            if (arr[j] > arr[j + 1]) {
                temp = arr[j + 1];
                arr[j + 1] = arr[j];
                arr[j] = temp;
            }
        }
    }
}

void find(int arr[10], int l, int a) {
    int f = 0, flag = 0;
    while (l - f) {
        int m = (f + l) / 2;
        if (a > arr[m])
            f = m + 1;
        else if (a < arr[m])
            l = m;
        else {
            flag = 1;
            cout << "找到了，是第" << m + 1 << "个\n";
            break;
        }
    }
    if (flag == 0)
        cout << "未找到\n";
}

int main() {
    int arr[10], i;
    cout << "请为数组赋10个数\n";
    for (i = 0; i < 10; i++) {
        cin >> arr[i];
    }
    px(arr);
    find(arr, 10, 50);
    return 0;
}
