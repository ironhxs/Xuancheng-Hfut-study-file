//# include <iostream>
//using namespace std;
//int main(){
//int x,a,b,c,d;
//float out;
//cin >>x >>a >>b >>c >>d >>out;
//out = x+(a+b)/(c-d);
//cout<<"�����"<<out<<endl; 
//return 0;
//}
















//# include <iostream>
//# include <math.h>
//using namespace std;
//int main(){
//int x;
//float out,out2;
//cin >>x;
//out = 1+1/(x+(1/(x+1)));
//out2=sqrt(out);
//cout<<"�����"<<sqrt(out)<<endl; 
//return 0;
//}

//# include <iostream>
//# include <math.h>
//#include <cmath>
//using namespace std;
//int main(){
//int x;
//float out;
//cin >>x;
//out =sin(x)+cos(x)+atan(x)*180/3.14;
//cout<<"�����"<<out<<endl; 
//return 0;
//}




//# include <iostream>
//# include <math.h>
//#include <cmath>
//using namespace std;
//int main(){
//int x,y;
//float out;
//cin >>x >>y;
//out =exp(x+y)+exp(x-y);
//cout<<"�����"<<out<<endl; 
//return 0;
//}


//# include <iostream>
//# include <math.h>
//#include <cmath>
//using namespace std;
//int main(){
//int x;
//float out;
//cin >>x;
//out =log10(1+sqrt(1+x^2));
//cout<<"�����"<<out<<endl; 
//return 0;
//}


//# include <iostream>
//# include <math.h>
//#include <cmath>
//using namespace std;
//int main(){
//int a,b;
//float out;
//cin >>a>>b;
//out =abs(a^2-b^2)+floor(a-b);
//cout<<"�����"<<out<<endl; 
//return 0;
//}






































































