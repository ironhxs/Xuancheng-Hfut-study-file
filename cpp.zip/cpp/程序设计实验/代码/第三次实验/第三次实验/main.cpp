//#include <iostream>
//using namespace std;
//struct element {  //定义链表中的结点结构
//              int val;
//              element *next;
//};
//
//
//
//
//class list {  //定义链表类
//              element *elems;
//           public:
//             list() {elems=0;}
//             ~list();
//             virtual bool insert(int);  //此虚函数在派生类中可重新定义
//             virtual bool deletes(int); //此虚函数在派生类中可重新定义
//             virtual int get();
//             bool contain(int);
//             void print();
//    element* get_elems();
//};
//
//
//
//
//class set:public list {   //将集合类set定义为链表类list的派生类
//           int card;
//         public:
//           set() {card=0; }
//           bool insert(int);  //重定义此函数
//           bool deletes(int); //重定义此函数
//    set b ( set others);
//    set j ( set others);
//    set c ( set others);
//
//};
//
//list::~list()  //list类得析构函数定义，循环释放各元素所占的存储
//{
//  element *tmp=elems;
//  for(element *elem=elems; elem!=0;)
//  {
//      tmp=elem;
//      elem=elem->next;
////      delete tmp;
//  }
//}
//
//
//
//
//bool list::insert(int val)   //定义list类中插入元素的成员函数
//{
//  element *elem=new element;  //为新元素分配存储
//  if (elem!=0) {
//      elem->val=val;    //将新元素插入到链表头
//      elem->next=elems;
//      elems=elem;
//      return true;
//  }
//  else return false;
//}
//bool list::deletes(int val)   //定义list类中删除元素的成员函数
//{
//  if(elems==0) return false;    //若表为空，返回false
//  element *tmp=elems;
//  if(elems->val==val)
//  {                     //若待删除的元素为表头元素
//    elems=elems->next;
//    delete tmp;
//    return true;
//  }
//  else
//    for(element *elem=elems; elem->next!=0; elem=elem->next)
//      if(elem->next->val==val)
//      {                     //循环查找待删除元素
//         tmp=elem->next;
//         elem->next=tmp->next;
//         delete tmp;
//         return true;
//      }
//  return false;
//}
//int list::get()   //定义list类中取首结点元素的成员函数
//{
//    int temp=elems->val;
//    elems=elems->next;
//      return temp;
//}
//bool list::contain(int val)
//{                       //判元素val在链表中是否存在
//  if(elems==0)return false;
//  if(elems->val==val) return true;
//  else
//    for(element *elem=elems; elem->next!=0; elem=elem->next)
//      if(elem->next->val==val)
//        return true;
//  return false;
//}
//
//void list::print()   //输出链表中各元素
//{
//  if(elems==0) return;
//  for(element *elem=elems; elem!=0; elem=elem->next)
//      cout<<elem->val<<"  ";
//  cout<<endl;
//}
//element* list ::get_elems(){
//    return elems;
//}
//bool set::insert(int val)  //在set类中的insert的重定义版本
//{
//  if(    !list::contain( val)&&list::insert(val)    )
//  {         //先判断此元素是否存在，然后再调用基类的此函数版本
//    ++card;
//    return true;
//  }
//  return false;
//}
//
//bool set::deletes(int val) //在set类中的deletes的重定义版本
//{
//  if(list::deletes(val))  //调用基类中的此函数版本
//  {     --card;   ;
//     return true;
//  }
//  return false;
//}
////set set::b ( set  others){
////    set temp;
////    element * p= others.get_elems();
////    element * q= get_elems();
////    while (p!=NULL) {
////        temp.insert(p->val);
////        p=p->next;
////    }
////    while (q!=NULL) {
////        temp.insert(q->val);
////        q=q->next;
////    }
////    return temp;
////}
////set set::j ( set  others){
////    set temp;
////    element * q= others.get_elems();
////    element * p= get_elems();
////    while (p!=NULL) {
////        temp.insert(p->val);
////        p=p->next;
////    }
////    while (q!=NULL) {
////        if(temp.contain(q->val)==false){
////            temp.deletes(q->val);
////        }
////        q=q->next;
////    }
////    return temp;
////}
////set set::c ( set  others){
////    set temp;
////    element * q= others.get_elems();
////    element * p= get_elems();
////    while (p!=NULL) {
////        temp.insert(p->val);
////        p=p->next;
////    }
////    while (q!=NULL) {
////        if(temp.contain(q->val)!=false)
////            temp.deletes(q->val);
////        q=q->next;
////    }
////    return temp;
////}
//
//
//int main() {
//   
////      list *ptr,list1;
////      set set1;
////      ptr=&list1;
////      ptr->insert(30);
////      ptr->insert(40);
////      ptr->insert(543);
////      ptr->insert(40);
////      ptr->print();
////      ptr=&set1;
////      ptr->insert(23);
////      ptr->insert(672);
////      ptr->insert(456);
////      ptr->insert(23);
////      ptr->print();
//////      getch();
////      return 1;
//    
////test b:
////    set *ptr,*pt;
////    set set1,set2;
////    pt=&set1;
////    pt->insert(30);
////    pt->insert(40);
////    pt->insert(543);
////    pt->insert(40);
////    pt->print();
////    ptr=&set2;
////    ptr->insert(23);
////    ptr->insert(672);
////    ptr->insert(456);
////    ptr->insert(30);
////    ptr->print();
////    (set2.b(set1)).print();
////      getch();
//    
//    //test j:
//        set *ptr,*pt;
//        set set1,set2;
//        pt=&set1;
//        pt->insert(30);
//        pt->insert(40);
//        pt->insert(543);
//        pt->insert(40);
//        pt->print();
//        ptr=&set2;
//        ptr->insert(23);
//        ptr->insert(672);
//        ptr->insert(456);
//        ptr->insert(30);
//        ptr->print();
//        (set1.j(set2)).print();
//    //      getch();
//    return 1;
//
//    }
//
//
//
////实验十
//#include <iostream>
//#include <string.h>
//using namespace std;
//
//class binary {    //定义二进制类
//              public:
//               char bits[16];  //二进制字模数组
//               binary(const char *);   //字符串参数构造函数
//               binary(int);      //整型参数构造函数
//    binary operator +( binary n2);
//    binary operator -(binary n2);
//    binary operator ~();
//    binary operator &(binary n2);
//    binary operator |(binary n2);
//               operator int();  //类类型转换函数
//               void print();
//};
//
// binary::binary(const char *num)
// {
//   int isrc=strlen(num)-1;    //字符串长度-1为最低位
//   int idest=15;
//   while(isrc>=0 && idest>=0)
//     bits[idest--]=(num[isrc--]=='0'?'0':'1');    // 逐位赋值
//   while(idest>=0) bits[idest--]='0';          // 空高位值0
//
// }
//
// binary::binary(int num)
// {
//   for(int i=15; i>=0;i--)
//   { bits[i]=(num % 2==0?'0':'1');   //求余数
//     num>>=1;            //移位，相当于整除2
//   }
// }
//
//binary binary::operator +(binary n2)
// {
//   unsigned carry=0;
//   unsigned value;
//   binary res="0";
//   for(int i=15; i>=0; i--)
//   {
//     value=(bits[i]=='0'?0:1)+ (n2.bits[i]=='0'?0:1)+carry;
//     res.bits[i]=(value%2==0?'0':'1');
//     carry=value>>1;
//   }
//   return res;
// }
//
//binary binary:: operator -(binary n2)
// {
//   unsigned borrow=0;
//   int value;
//   binary res="0";
//   for(int i=15; i>=0; i--)
//   {
//     value=(bits[i]=='0'?0:1)-(n2.bits[i]=='0'?0:1)+borrow;
//     res.bits[i]=(value==-1||value==1?'1':'0');
//       borrow=(value==-1||(borrow!=0&&(value==0||value==1))?1:0);
//   }
//   return res;
// }
//binary binary:: operator ~()
// {
//   binary res="0";
//   for(int i=15; i>=0; i--)
//   {
//     res.bits[i]=(bits[i]=='0'?'1':'0');
//   }
//   return res;
// }
//binary binary::operator &(binary n2)
// {
//   binary res="0";
//   for(int i=15; i>=0; i--)
//   {
//       if (bits[i]=='1'&&n2.bits[i]=='1') {
//           res.bits[i]='1';
//       }
//       else
//           res.bits[i]='0';
//   }
//   return res;
// }
//binary binary::operator |(binary n2)
// {
//   binary res="0";
//   for(int i=15; i>=0; i--)
//   {
//       if (bits[i]=='0'&&n2.bits[i]=='0') {
//           res.bits[i]='0';
//       }
//       else
//           res.bits[i]='1';
//   }
//   return res;
// }
// binary::operator int()
// {
//   unsigned value=0;
//   for(int i=0; i<=15; i++)
//     value=( value*2)+(bits[i]=='0'?0:1);
//   return value;
// }
//
// void binary::print()
// {
//   char str[17];
//   strncpy(str,bits,16);
//   str[16]='\0';
//   cout<<str<<"\n";
// }
//
// int main()
// {
//   binary n1("1011");
//   binary n2=int(n1)+15;
//   binary n3=n1-binary(7);
//     (n1|n2).print();
//     (n1&n2).print();
//   n1.print();
//   n2.print();
//   n3.print();
//   cout<<int(n2)+5<<endl;
//   cout<<n2 - binary(5)<<endl;
//   cout<<n3 + binary(5)<<endl;
//   cout<<int(n3)-5<<endl;
//     return 1;
// }
#include <iostream>
using namespace std;
struct element {  //定义链表中的结点结构
              int val;
              element *next;
};

class list {  //定义链表类
              element *elems;
           public:
             list() {elems=0;}
             ~list();
             virtual bool insert(int);  //此虚函数在派生类中可重新定义
             virtual bool deletes(int); //此虚函数在派生类中可重新定义
             virtual int get();
             bool contain(int);
             void print();
    element* get_elems();
};

class set:public list {   //将集合类set定义为链表类list的派生类
           int card;
         public:
           set() {card=0; }
           bool insert(int);  //重定义此函数
           bool deletes(int); //重定义此函数
    set operator  + ( set others);
    set operator  - ( set others);
    set operator  *  ( set others);
    ostream& operator << (ostream& out ) ;

};

list::~list()  //list类得析构函数定义，循环释放各元素所占的存储
{
  element *tmp=elems;
  for(element *elem=elems; elem!=0;)
  {
      tmp=elem;
      elem=elem->next;
//      delete tmp;
  }
}

bool list::insert(int val)   //定义list类中插入元素的成员函数
{
  element *elem=new element;  //为新元素分配存储
  if (elem!=0) {
      elem->val=val;    //将新元素插入到链表头
      elem->next=elems;
      elems=elem;
      return true;
  }
  else return false;
}
bool list::deletes(int val)   //定义list类中删除元素的成员函数
{
  if(elems==0) return false;    //若表为空，返回false
  element *tmp=elems;
  if(elems->val==val)
  {                     //若待删除的元素为表头元素
    elems=elems->next;
    delete tmp;
    return true;
  }
  else
    for(element *elem=elems; elem->next!=0; elem=elem->next)
      if(elem->next->val==val)
      {                     //循环查找待删除元素
         tmp=elem->next;
         elem->next=tmp->next;
         delete tmp;
         return true;
      }
  return false;
}
int list::get()   //定义list类中取首结点元素的成员函数
{
    int temp=elems->val;
    elems=elems->next;
      return temp;
}
bool list::contain(int val)
{                       //判元素val在链表中是否存在
  if(elems==0)return false;
  if(elems->val==val) return true;
  else
    for(element *elem=elems; elem->next!=0; elem=elem->next)
      if(elem->next->val==val)
        return true;
  return false;
}

void list::print()   //输出链表中各元素
{
  if(elems==0) return;
  for(element *elem=elems; elem!=0; elem=elem->next)
      cout<<elem->val<<"  ";
  cout<<endl;
}
element* list ::get_elems(){
    return elems;
}
bool set::insert(int val)  //在set类中的insert的重定义版本
{
  if(    !list::contain( val)&&list::insert(val)    )
  {         //先判断此元素是否存在，然后再调用基类的此函数版本
    ++card;
    return true;
  }
  return false;
}

bool set::deletes(int val) //在set类中的deletes的重定义版本
{
  if(list::deletes(val))  //调用基类中的此函数版本
  {     --card;   ;
     return true;
  }
  return false;
}
set set:: operator + ( set  others){
    set temp;
    element * p= others.get_elems();
    element * q= get_elems();
    while (p!=NULL) {
        temp.insert(p->val);
        p=p->next;
    }
    while (q!=NULL) {
        temp.insert(q->val);
        q=q->next;
    }
    return temp;
}
set set::operator * ( set  others){
    set temp;
    element * q= others.get_elems();
    element * p= get_elems();
    while (p!=NULL) {
        temp.insert(p->val);
        p=p->next;
    }
    while (q!=NULL) {
        if(temp.contain(q->val)==false){
            temp.deletes(q->val);
        }
        q=q->next;
    }
    return temp;
}
set set::operator -  ( set  others){
    set temp;
    element * q= others.get_elems();
    element * p= get_elems();
    while (p!=NULL) {
        temp.insert(p->val);
        p=p->next;
    }
    while (q!=NULL) {
        if(temp.contain(q->val)!=false)
            temp.deletes(q->val);
        q=q->next;
    }
    return temp;
}
ostream& set:: operator << (ostream& out ) //输出链表中各元素
{element *p=get_elems();
  if(p==0) return out ;
  for(element *elem=p; elem!=0; elem=elem->next)
      out<<elem->val<<"  ";
  cout<<endl;
    return out;
}

