//
//  2.cpp
//  实验作业
//
//  Created by 贺鑫帅 on 2023/10/16.
//
//（1）
//
//原题程序乱码了
//
//
//
//（2）编写程序实现下列问题的求解
// <1>
//#include <iostream>
//#include <math.h>
//using namespace std;
//int main() {
//    double x,y,z;
//    cout<<"请输入两个整数x，y\n";
//    cin>>x>>y;
//    if (x<0&&y<0) {
//        z=exp(x+y);
//    }
//    else if(1<=(x+y)<10){
//        z=log(x+y);
//    }
//    else{
//        z=log10(fabs((x+y)+1));
//        
//    }
//    cout<<"结果是"<<z<<endl;
//        
//    return 0;
//}
//
//
//
//
// <2>
//  1)
//#include <iostream>
//using namespace std;
//int main() {
//    int i;
//    int s=0;
//    for (i=1; i<101; i++) {
//        s+=i;
//    }
//    cout<<"1到100之和为"<<s<<endl;
//   
//        
//    return 0;
//}
//
//
//
// 2)
//#include <iostream>
//using namespace std;
//int i;
//int b=1;
//int j(int a){
//    for (i=1; i<=a; i++) {
//        b*=i;}
//        return b;
//    }
//
//    int main(void) {
//    int s=0;
//    for (i=1; i<8; i++) {
//        s+=j(i);
//    }
//    cout<<"结果是"<<s<<endl;
//    return 0;
//}
//
//
//
// 3)
//#include <iostream>
//using namespace std;
//int s=0;
//int i;
//int ch(int a){
//    int b=1;
//    b=(2*a-1)*2*a;
//    return b;
//    
//}
//int main() {
//    for (i=1; i<21; i++) {
//        s+=ch(i);
//    }
//    cout<<"结果是"<<s<<endl;
//   
//        
//    return 0;
//}
//
//
//
//
// 4)
//#include <iostream>
//# include<cmath>
//using namespace std;
//double x,n,i;
//double s=0;
//cout<<"请为x，n分别赋值/n"
//cin>>x>>n;
//int j(int a){
//    int i;
//    int b=1;
//    for (i=1; i<=a; i++) {
//        b*=i;}
//        return b;
//    }
//double dd (double x,double n){
//    int c =0;
//    c= pow(-1)(n+1)* pow(x)(2*n-1)/j(2n-1)
//    return c;
//}
//
//int main() {
//    for (i=1;i<n;i++){
//        s+=dd(x,n);
//        }
//    cout<<"结果是"<<s<<endl;
//    return 0;
//}
//
//
//
//
// <3>
//#include <iostream>
//using namespace std;
//int main() {
//    int i,j,a;
//    for(i=1;i<12;i++){
//        for(a=1;a<2*(12-i);a++){
//            cout<<" ";
//        }
//        for(j=1;j<2*i-1;j=j+2){
//            cout<<j<<" ";
//            
//        }
//        for(j=2*i-1;j>0;j=j-2){
//            cout<<j<<" ";
//        }
//        for(a=1;a<2*(12-i);a++){
//            cout<<" ";
//        }
//        cout<<"\n";
//
//        
//    }
//         
//        
//    return 0;
//}
//
//
//
//
// <4>
//#include <iostream>
//using namespace std;
//int main() {
//    int i;
//    int j=1;
//    for(i=1;i<11;i++){
//        j=1;
//    while (i>j) {
//        cout<<"<"<<i<<","<<j<<"> ";
//        j++;
//    }
//        }
//     return 0;
//}
//
//
//
// <5> 错误方法
//#include <iostream>
//using namespace std;
//int main() {
//    int i,j,k,l;
//    for (i=9; i>0; i--) {
//        for (j=8; 0<j<i; i--) {
//            for (k=7;0< k<j; k--) {
//                for (l=6; 0<=l<k; l--) {
//                    cout<<i<<j<<k<<l<<" ";
//                }
//            }
//        }
//    }
//   return 0;
//}
//
//
//
//改正方法
//#include <iostream>
//using namespace std;
//int main() {
//    int i;
//    for (i=1; i<=10000; i++) {
//        if((i%1000)>((i/1000)%100)>((i/100)%10)){
//            cout<<i<<" ";
//        }
//     }
//   return 0;
//}
//
//
//
//// <6>
//#include <iostream>
//#include <math.h>
//using namespace std;
//int judge(int a){
//    int flag =1;
//    int k;
//    for (k=0; k<sqrt(a); k++) {
//        if (a%k==0) {
//            flag=0;
//        }
//    }
//    return flag;
//
//    }
//int main() {
//    int a,i,t;
//    cout<<"请输入一个整数\n";
//    cin>>a;
//    for (i=1; i<sqrt(a); i++) {
//        for(t=sqrt(a);t<a;t++){
//            if (judge(i)&&judge(t)&&a==i*t) {
//                cout<<i<<"*"<<t<<"="<<a<<endl;
//            }
//        }
//    }
//      return 0;
//}














