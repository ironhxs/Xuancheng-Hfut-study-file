//
//  main.cpp
//  实验作业
//
//  Created by 贺鑫帅 on 2023/10/16.
//
//一
//#include <iostream>
//using namespace std;
//int main() {
//    int a,b,i;
//       cout<<"请输入一个四位整数\n";
//       cin>>a;
//       for(i=0;i<4;i++){
//           b=a%10;
//           a=a/10;
//           cout<<b;
//        }
//    return 0;
//}
