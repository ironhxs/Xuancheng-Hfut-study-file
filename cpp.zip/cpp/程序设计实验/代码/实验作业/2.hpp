//
//  2.hpp
//  实验作业
//
//  Created by 贺鑫帅 on 2023/10/16.
//

#ifndef __hpp
#define __hpp

#include <stdio.h>

#endif /* __hpp */
