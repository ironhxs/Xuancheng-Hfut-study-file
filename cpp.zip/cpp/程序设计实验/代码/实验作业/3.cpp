//
//  3.cpp
//  实验作业
//
//  Created by 贺鑫帅 on 2023/10/17.
//
//
//
// （2）
//  <1>

//#include <iostream>
//using namespace std;
//int main() {
//    int a[10]={0};
//    int b[10]={0};
//    int c[10]={0};
//    int i;
//    cout<<"1)  ";
//    for (i=1; i<11; i++) {
//        a[i-1]=i*i;
//    }
//    for (i=0; i<10; i++) {
//        cout<<a[i]<<" ";
//    }
//    cout<<"\n2)  ";
//    b[0]=1;
//    for (i=1; i<10; i++) {
//        b[i]=b[i-1]+i+1;
//    }
//    for (i=0; i<10; i++) {
//        cout<<b[i]<<" ";
//    }
//    cout<<"\n3)  ";
//    c[0]=1;
//    c[1]=2;
//    c[2]=3;
//    for (i=3; i<10; i++) {
//        c[i]=2*c[i-1]-c[i-3];
//    }
//    for (i=0; i<10; i++) {
//        cout<<c[i]<<" ";
//    }
//    return 0;
//}
//
//
//
// ⑵二维数组
// 1)
//#include <iostream>
//using namespace std;
//int main() {
//    int a[6][6]={0};
//    int i,t,k;
//    for (i=0; i<6; i++) {
//        k=i+1;
//        for (t=0; t<6; t++) {
//            
//        if (k<7) {
//            a[i][t]=k;
//        }
//            else
//                a[i][t]=k-7;
//            k++;
//        }
//     }
//    for (i=0; i<6; i++) {
//        for (t=0; t<6; t++) {
//            cout<<a[i][t]<<" ";
//        }
//        cout<<endl;
//    }
//   
//        
//    return 0;
//}
//
//  3）
//
//#include <iostream>
//using namespace std;
//void cn(){
//    int a[6][6]={0};
//    int i,t;
//    for (i=0; i<6; i++) {
//        t=i+1;
//        int j=0,l;
//        while(j++<6){
//            if(t--)
//                a[i][j]=t;
//            else
//                for(l=1;l<7-i;l++)
//                    a[i][j]=l;
//             }
//    }
//    for (i=0; i<6; i++) {
//        for (t=0; t<6; t++) {
//            cout<<a[i][t]<<" ";
//        }
//        cout<<endl;
//    }}
//
//int main() {
//    
//    int cn(int n);
//        
//    return 0;
//}
//
//
//
//
//#include <iostream>
//using namespace std;
//int main() {
//    int i,t,k;
//    int a[6][8]={0};
//    for (i=0; i<8; i++) {
//        k=i+5;
//        if (k>6){
//            k=k-6;
//        }
//        a[i][0]=k;
//        
//    }
////                for (t=1; t<7; t++) {
////            if (a[i][t-1]==6) {
////                a[i][t]=0;;
////            }
////            else
////                a[i][t]=a[i][t-1]+1;
////    }
//    for (i=0; i<8; i++) {
//           for (t=0; t<6; t++) {
//               cout<<a[i][t]<<" ";
//           }
//           cout<<endl;
//       }
//   
//        
//
//}
//

//4）
//#include <iostream>
//using namespace std;
//int main() {
//    int i,t;
//    char a[5][6]={0};
//    a[0][0]='A';
//    for (i=0; i<6; i++) {
//        a[0][i]='A'+i;
//    }
//    for (i=0; i<5; i++) {
//        a[i][0]='A'+i;
//    }
//    for (i=1; i<5; i++) {
//        for (t=1;t<6; t++) {
//            a[i][t]=a[i][t-1]+t;
//            
//        }
//    }
//    
//    
//    for (i=0; i<5; i++) {
//        for (t=0; t<6; t++) {
//            cout<<a[i][t]<<" ";
//        }
//        cout<<endl;
//        
//        
//        
//    }
//    return 0;
//}






// <2>
//#include <iostream>
//using namespace std;
//int main() {
//    int i,t;
//    int arr[15];
//    cout<<"请输入15个整数\n";
//    for (i=0; i<15; i++) {
//        cin>>arr[i];
//    }
//    for (i=0; i<14; i++) {
//                for (t=0; t<14-i; t++) {
//                    int temp;
//                    if (arr[t]>arr[t+1]) {
//                        temp =arr[t];
//                        arr[t]=arr[t+1];
//                        arr[t+1]=temp;}
//
//        }
//            }
//    for (i=0; i<15; i++) {
//        cout<<arr[i]<<"  ";
//    }
//      return 0;
//}




//
// <3>

//#include <iostream>
//using namespace std;
//# include <ctime>
//int x(){
//    srand((unsigned int)time(NULL));
//    return 1+rand()%100;
//}
//int main() {
//    int i;
//    int arr[9];
//    for (i=0; i<9; i++) {
//        arr[i]=x();
//    }
//    
//   
//        
//    return 0;
//}





// <4>
#include <iostream>
using namespace std;
# include <ctime>
int a,f,l,m;
void bubble_sort(int arr[], int sz){
 int i = 0;
 for(i=0; i<sz-1; i++)
{
 int j = 0;
 for(j=0; j<sz-i-1; j++)
{
 if(arr[j] > arr[j+1])
    {
         int tmp = arr[j];
         arr[j] = arr[j+1];
         arr[j+1] = tmp;
    } }

} }
int main() {
    int arr[9];
    int i;
    cout<<"输入九个数"<<endl;
    for (i=0; i<9 ; i++) {
        cin>>arr[i];
        
    }
    bubble_sort(arr, 9);
   

    cout<<"请输入一个整数"<<endl;
    cin>>a;
    int flag = 0;
    f=0;
    l=8;
    while(l-f){                                     //判断条件 开始想错为m
        m=(f+l)/2;
        if (a<arr[m]&&a>arr[f]) {
            l=m;
        }
        else if(a>arr[m]&&a<arr[l]) {
            f=m;
        }
        else if(arr[m]==a){
            flag =1;
            break;} //忘记修改 也没break
        else
            break;//优化:可以提高效率
            }
    if (flag == 1) {
        cout<<"存在，是数组第"<<m+1<<"位"<<endl;//m和m+1位
    }
else
        cout<<"不存在"<<endl;
        
    return 0;
}





// <5>
//#include <iostream>
//using namespace std;
//# include <ctime>
//int x(){
//    srand((unsigned int)time(NULL));
//    return 1+rand()%100;
//}
//
//int i =0;
//void jie(char a[9],char b[9],char c[18]){//设置数组长度不好处理
//    while (i<=(18)) {
//        if(i<=9)
//            c[i]=a[i];
//        else
//            c[i]=b[i-9];
//            
//        }
//    }
//
//int main() {
//    char a[9],b[9],c[18];
//    cout<<"请输入9个字符";
//    for (i=0; i< 9; i++) {
//        cin>>a[i]  ;     }
//    cout<<"请输入9个字符";
//    for (i=0; i< 9; i++) {
//        cin>>b[i]  ;      }
//    jie(&a[9], &b[9],&c[18]);
//    for (i=0; i<18; i++) {
//        cout<<c[i]<<" \n";
//    }
//    return 0;
//}
