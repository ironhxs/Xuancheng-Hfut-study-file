////
////  main.cpp
////  实验作业二
////
////  Created by 贺鑫帅 on 2023/11/7.
//// 四(2) 1
//#include <iostream>
//using namespace std;
//void func0(int a,int b,int c,double d){
//    double x,y;
//    x=(-b)/2*a;
//    y=sqrt(-d)/2*a;
//    cout<<"有虚根实部为"<<x<<" "<<"虚部为"<<y<<endl;
//}
//void func1(int a,int b,int c){
//    int x=0;
//    while (a*pow(x, 2)+b*x+c) {
//        x++;
//    }
//    cout<<"一个根"<<x<<endl;;
//}
//
//void func2(int a,int b,int c,double d){
//    double  x,y;
//    x=(b+sqrt(d))/2*a;
//    y=(-b+sqrt(d))/2*a;
//    cout<<"有两根分别为"<<x<<" "<<y<<endl;
//}
//int main() {
//    int a,b,c;
//    double d;
//    cout<<"请为二次函数的三个系数赋值\n";
//    cin>>a>>b>>c;
//    d=b*b-4*a*c;
//    if (d<0) {
//        func0(a,b,c,d);
//    }
//    else if(d==0)
//        func1(a,b,c);
//    else
//        func2(a,b,c,d);
//    
//    return 0;
//}
//
//
// <2>
//#include <iostream>
//using namespace std;
//#include <cmath>
//#include <string>
//int  turn(char a){
//    if (a>='A'&&a<='F') {
//        return a-'A'+10;
//    }
//    else if(a>'0'&&a<'9')
//        return a-'0';
//    else
//        return -1;
//}
//int trans(string a){
//    int r=0,i=0,j=0;
//    for (i=(a.length()-1);i>=0 ;i--) {
//        r+=turn(a[i])*pow(16, j);
//        j++;
//    }
//    return r;
//}
//int main() {
//    string a;    cout<<"一个以字符串形式表示的十六进制数\n";
//    cin>>a;
//    trans(a);
// cout<<"转化结果为"<<trans(a)<<endl;
//    return 0;
//}
// <3>
//#include <iostream>
//using namespace std;
//string trans(int a){
//    string b="";
//    while (a>0) {
//        int e=a%16;
//        char c;
//        if (a<10) {
//            c='0'+e;
//        }
//        else
//            c='A'+(e%10);
//        b+=c;
//        a=a/16;
//    }
//    return b;
//}
//int main() {
//    int a;
//    cout<<"请输入一个十进制整数\n";
//    cin>>a;
//    cout<<"该十进制数转化为"<<trans(a)<<endl;
//    return 0;
//}
// <4>
//
//#include <iostream>
//#include<cmath>
//using namespace std;
//int i,h;
//int judge(int a){
//    int flag=1,i;
//    for (i=2; i<sqrt(a)+1; i++) {
//        if (a%i==0) {
//            flag=0;
//            break;
//        } }
//        if (flag==0) {
//            return 0;
//        }
//        else
//            return 1;
//}
//int main() {
//    int arr[2000],t=0;
//    for (i=2; i<2000; i++) {
//        if (judge(i)) {
//            arr[t]=i;
//            t++;
//        }
//    }
//    for (i=0; i<t; i++) {
//        if (arr[i+1]-arr[i]>10) {
//            for (h=arr[i]; h<=arr[i+1]; h++) {
//                cout<<h<<" ";
//            }
//            cout<<endl;
//        }
//    }
//    return 0;
//}
//
//
//
// 1.string 长度及取出
// 2.字符与数字联系 
//
//
//
//
////实验五
//// (2)
//#include <iostream>
//using namespace std;
//void pxn(int a,int b,int c){
//    int temp,i,j,arr[3];
//    arr[0]=a;
//    arr[1]=b;
//    arr[2]=c;
//    for (i=0; i<2; i++) {
//        for (j=0; j<2-i; j++) {
//            if (arr[j]>arr[j+1]) {
//                temp=arr[j+1];
//                arr[j+1]=arr[j];
//                arr[j]=temp;
//            }
//        }
//    }
//    for (i=0; i<3; i++) {
//        cout<<arr[i]<<" ";
//    }
//}
//void pxs(string a,string b,string c){
//    string arr[3],temp;
//    int i,j;
//    arr[0]=a;
//    arr[1]=b;
//    arr[2]=c;
//    for (i=0; i<2; i++) {
//        for (j=0; j<2-i; j++) {
//            if (arr[j][0]>arr[j+1][0]) {
//                temp=arr[j+1];
//                arr[j+1]=arr[j];
//                arr[j]=temp;
//            }
//        }
//    }
//    for (i=0; i<3; i++) {
//        cout<<arr[i]<<" ";
//    }
//}
//    
//
//int main() {
//    int a,b,c;
//    string d,e,f;
//    cout<<"请输入三个整数\n";
//    cin>>a>>b>>c;
//    cout<<"请输入三个字符串\n";
//    cin>>d>>e>>f;
//    pxn(a, b, c);
//    pxs(d,e,f);
//    return 0;
//}
//
// <2>
//#include <iostream>
//using namespace std;
//int i,j;
//void turn(int arr[3][3]){
//    int temp[3][3];
//    for (i=0; i<3; i++) {
//        for (j=0; j<3; j++) {
//            temp[i][j]=arr[i][j];
//        }}
//        for (i=0; i<3; i++) {
//            for (j=0; j<3; j++) {
//                arr[i][j]=temp[j][i];
//            }
//            
//        }
//    }
//int main() {
//    int arr[3][3];
//    cout<<"请为数组赋值\n";
//    for (i=0; i<3; i++) {
//        for (j=0; j<3; j++) {
//            scanf("%d",&arr[i][j]);
//        }}
//        turn(arr);
//        for (i=0; i<3;i++) {
//            for (j=0; j<3; j++) {
//                cout<<arr[i][j]<<" ";
//            }
//            cout<<endl;
//        }
//    return 0;
//}
// <3>
//#include <iostream>
//#include <string>
//using namespace std;
//int _strcmp(string a,string b){
//    int x=0,y=0,i=0;
//    while (a[i]!='\0') {
//        x+=a[i]-'a';
//        i++;
//    }
//    i=0;
//    while (b[i]!='\0') {
//        y+=b[i]-'a';
//        i++;
//    }
//    if (x>y)
//        return 1;
//   else if(x==y)
//       return 0;
//    else
//        return -1;
//
//}
//int main() {
//    string a,b;
//    cout<<"请为第一个字符串赋值\n";
//    getline(cin,a);
//    cout<<"请为第二个字符串赋值\n";
//    getline(cin,b);
//    cout<<_strcmp(a,b)<<endl;
//    return 0;
//}
//
// <4>
//单向
//#include <iostream>
//using namespace std;
//struct node{
//    int a;
//    node* next;
//    node* last;
//};
//int main() {
//    node*p,*head=NULL,*q;
//    node*end=new node;
//    head=end;
//    int a;
//    cin>>a;
//    end->a=a;
//    do{ cin>>a;
//        p=new node;
//        p->a=a;
//        p->next=head;
//        head=p;
//    }while (a!=-1) ;
//    p=head;
//    q=head;
//    p->last=NULL;
//    while (1) {
//         p=p->next;
//        p->last=q;
//        q=q->next;
//        if (p==end) {
//            break;
//        }
//    }
//    p=end;
//    cout<<p->a;
//    while (p!=NULL) {
//        cout<<p->a<<' ';
//        p=p->last;
//    }
//    
//    
//    cout<<endl;
//    return 0;
//}
//
////实验六
//// <1>
//#include <iostream>
//using namespace std;
//
//struct student {
//    int id;
//    string name;
//    int score;
//    string ps;
//};
//
//class clas {
//public:
//    student a[40];
//    static int n;
//    
//    clas() {
//        n = 0;
//    }
//
//    void set() {
//        int i = 0;
//        cout << "请按照学号,姓名,成绩,备注的顺序输入学生信息\n";
//        while (i < 40) {
//            cin >> a[i].id;
//            if (a[i].id == -1) {
//                break;
//            }
//            cin >> a[i].name >> a[i].score >> a[i].ps;
//            n++;
//            i++;
//        }
//    }
//
//    void get() {
//        for (int i = 0; i < n; i++) {
//            if (a[i].id != -1) {
//                cout << a[i].id << ' ' << a[i].name << ' ' << a[i].score << ' ' << a[i].ps << ' ' << endl;
//            }
//        }
//        cout << endl;
//    }
//
//    void px() {
//        for (int i = 0; i < n - 1; i++) {
//            for (int j = 0; j < n - 1 - i; j++) {
//                if (a[j + 1].score > a[j].score) {
//                    student temp = a[j + 1];
//                    a[j + 1] = a[j];
//                    a[j] = temp;
//                }
//            }
//        }
//    }
//
//    void find(int standard) {
//        for (int i = 0; i < n; i++) {
//            if (a[i].score >= standard) {
//                cout << a[i].id << ' ' << a[i].name << ' ' << a[i].score << ' ' << a[i].ps << ' ' << endl;
//            }
//        }
//        cout << endl;
//    }
//};
//
//int clas::n;
//
//int main() {
//    clas no1;
//    no1.set();
//    no1.px();
//    no1.get();
//    no1.find(90);
//    return 0;
//}
//
// <2>
#include <iostream>
using namespace std;
struct node{
    int id;
       string name;
       int score;
       string ps;
        node *next;
};
void get(node *head){
    node *p=head;
    while (p!=NULL) {
        cout<<p->name<<' '<<p->score<<' '<<p->ps<<endl;
        p=p->next;
    }
    cout<<endl;
}
void find(node *head,int standard){
    node *p=head;
    while (p!=NULL) {
        if (p->score>=standard) {
            cout<<p->name<<' '<<p->score<<' '<<p->ps<<endl;  }
        p=p->next;
    }
    cout<<endl;
}
node* px(node *head){
    node *fhead=new node;
    fhead->next=head;
    node *lp=fhead, *p=lp->next,*np=p->next,*temp=NULL;
    int n=0;
    p=head;
    while (p!=NULL) {
        p=p->next;
        n++;
    }
    for (int i=0; i<n-1; i++) {
        lp=fhead; p=lp->next;np=p->next;temp=NULL;
        for (int j=0; j<n-1-i; j++) {
            if (p->score<np->score) {
                lp->next=np;
                p->next=np->next;
                np->next=p;
                temp=np;
                np=p;
                p=temp;
            }
            lp=lp->next;
            p=p->next;
            np=np->next;
        }
    }
    node*t=fhead->next;
    delete fhead;
    return t;
}

int main() {
    node*p,*head=NULL;
    cout<<"请按照学号,姓名,成绩,备注的顺序输入学生信息\n";
    while (1) {
        p=new node;
        p->next=head;
        head=p;
        cin>>p->id;
        if (p->id==-1) {
            head=p->next;
            delete p;
            break;
        }
        cin>>p->name>>p->score>>p->ps;
    }
    get(head);
    find(head,90);
    get(px(head));
    return 0;
}























//
// <3>
//#include <iostream>
//using namespace std;
//#define swap(a,b){a=(a)^(b);b=(a)^(b);a=(a)^(b);}
//int main() {
//    int a,b;
//    cin>>a>>b;
//    swap(a, b);
//    cout<<a<<' '<<b<<endl;
//    return 0;
//}
