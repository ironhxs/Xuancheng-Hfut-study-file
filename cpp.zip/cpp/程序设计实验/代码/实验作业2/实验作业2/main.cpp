////
////  main.cpp
////  实验作业2
////
////  Created by 贺鑫帅 on 2023/10/25.
////
//// <5>
//#include <iostream>
//using namespace std;
//#include<cstring>
//int i;
//void  cat (char *a,int m,char*b,int n){
//    for ( i=m; i<m+n; i++) {
//        a[i] =b[i-m];
//    }
//    a[m+n]='\0';
//}
//int main() {
//    char a [200]="hello",b[99]="world";
//    int m=strlen(a);
//    int n =strlen (b);
//    cat (a,m,b,n);
//        cout<<a<<endl;
//    return 0;
//}
//
//
//
//#include <iostream>
//using namespace std;
//int main() {
//    int n,i,j;
//    cout<<"请输入n";
//    cin>>n;
//    int **a =new int* [n];
//    for (i=0; i<n; i++) {
//        a[i]=new int [n];
//    }
//    for (i=0; i<n; i++) {
//        for (j=0; j<n; j++) {
//            a[i][j]=(j+i+1)%n;
//        }
//    }
//    for (i=0; i<n; i++) {
//        for (j=0; j<n; j++) {
//            cout<<a[i][j]<<" ";
//        }
//        cout<<endl;
//    }
//        
//    return 0;
//}



//#include <iostream>
//using namespace std;
//int main() {
//    int i,j,t,k;
//    int arr[6][6];
//    for (i=0; i<6; i++) {
//        t=i+1;
//        k=1;
//        for (j=0; j<6; j++) {
//            if (t>1) {
//                arr[i][j]=t--;
//            }
//            else
//                arr[i][j]=k++;
//        }
//    }
//    for (i=0; i<6; i++) {
//        for (j=0; j<6; j++) {
//            cout<<arr[i][j]<<" ";
//        }
//        cout<<endl;
//    }
//    return 0;
//}


#include <iostream>
using namespace std;
void max(int*a,int *b){
    int max=*a>*b?*a:*b;
    int min=*a>*b?*b:*a;
    *a=max;
    *b=min;
}
int main() {
        int a,b,p,q,temp;
    cout<<"请输入两个正整数(从小到大)\n";
    cin>>a>>b;
    p=a;
    q=b;
     while(b){
         temp=b;
         b=a%b;
         a=temp;
       }
    cout<<"最大公因子为"<<a<<endl<<"最小公倍数为"<<p*q/a<<endl;
    return 0;
}
