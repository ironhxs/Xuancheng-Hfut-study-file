//
//  main.cpp
//  test
//
//  Created by 贺鑫帅 on 2023/10/24.
//

#include <iostream>


#include <iostream>
using namespace std;
void cn(int a[6][6]){
    int i,t;
//    for (i=0; i<6; i++) {
//        t=i+1;
//        int j=0,l;
//        while(j++<6){
//            if(t--)
//                a[i][j]=t;
//            else
//                for(l=1;l<7-i;l++)
//                    a[i][j]=l;
//             }
//    }
    a[6][6]={1,23,4,5,366,3,6,36,3,446,3};
    for (i=0; i<6; i++) {
        for (t=0; t<6; t++) {
            cout<<a[i][t]<<" ";
        }
        cout<<endl;
    }}

int main() {
    int a[6][6];
    void cn(int a[6][6]);
        
    return 0;
}
