//
//  main.cpp
//  骑士巡游
//
//  Created by 贺鑫帅 on 2024/1/3.
//

#include <iostream>
# include<string.h>
# include<iomanip>
using namespace std;
//参数
int n,x,y; //n地图规格 x y起始坐标

//int step=1;//记录此次走的方向(默认走方向1)

//解决函数 方案一:太过于粗暴,求解太复杂失败
//void solve(int * *CheB ,int n,int i , int j, int k, bool &ok,int step)
//{
//    if (k==n*n){
//        CheB[i][j]=1;
//    }
//    else
//    {   switch(step){
//        case 1:
//            if ((i-1)>=0&&(j-2)>=0&&CheB[i-1][j-2]==0) {
//                i-=1;
//                j-=2;
//                CheB[i][j]=n*n-k+1;
//                step=1;
//                break;
//            }
//        case 2: {if((i-1)>=0&&(j+2)<n&&CheB[i-1][j+2]==0) {
//            i-=1;
//            j+=2;
//            CheB[i][j]=n*n-k+1;
//            step=2;
//            break;
//        }
//        }
//        case 3:{if((i-2)>=0&&(j-1)>=0&&CheB[i-2][j-1]==0) {
//            i-=2;
//            j-=1;
//            CheB[i][j]=n*n-k+1;
//            step=3;
//            break;
//        }
//        }
//        case 4:{if((i-2)>=0&&(j+1)<n&&CheB[i-2][j+1]==0) {
//            i-=2;
//            j+=1;
//            CheB[i][j]=n*n-k+1;
//            step=4;
//            break;
//        }
//        }
//        case 5:{ if((i+1)<n&&(j-2)>=0&&CheB[i+1][j-2]==0) {
//            i+=1;
//            j-=2;
//            CheB[i][j]=n*n-k+1;
//            step=5;
//            break;
//        }
//        }
//        case 6:{if((i+1)<n&&(j+2)<n&&CheB[i+1][j+2]==0) {
//            i+=1;
//            j+=2;
//            CheB[i][j]=n*n-k+1;
//            step=6;
//            break;
//        }
//        }
//        case 7:{if((i+2)<n&&(j-1)>=0&&CheB[i+2][j-1]==0) {
//            i+=2;
//            j-=1;
//            CheB[i][j]=n*n-k+1;
//            step=7;
//            break;
//        }}
//        case 8 :{if((i+2)<n&&(j+1)<=n&&CheB[i+2][j+1]==0) {
//            i+=2;
//            j+=1;
//            CheB[i][j]=n*n-k+1;
//            step=8;
//            break;
//        }}
//                    default:{
//                            if(step<8)
//                            {   step+=1;
//                                solve(CheB , n, i ,  j,  k, ok,step);
//                            }
//                            else if(step==8&&k<(n*n))
//                            {
//                                step=2;
//                                solve(CheB , n, i ,  j,  k+1, ok,step);
//                            }
//                            else{
//                                cout<<"骑士没有成功巡游,公主run了~💔\n";
//                                ok=false;
//                                return;}}
//
//    }}
//        if(ok==true&&k==1){
//            cout<<"骑士🤴成功巡游找到公主👸\n";
//            return;
//        }
//        else
//        {
//            solve(CheB , n, i ,  j,  k-1, ok,1);
//        }
//    }
//递归回溯算法 改良的方案二:
//move函数 方案一
//void move(int step)
//{
//    switch(step){
//            case 1:
//                if ((i-1)>=0&&(j-2)>=0&&CheB[i-1][j-2]==0) {
//                    i-=1;
//                    j-=2;
//                    CheB[i][j]=n*n-k+1;
//                    step=1;
//                    break;
//                }
//            case 2: {if((i-1)>=0&&(j+2)<n&&CheB[i-1][j+2]==0) {
//                i-=1;
//                j+=2;
//                CheB[i][j]=n*n-k+1;
//                step=2;
//                break;
//            }
//            }
//            case 3:{if((i-2)>=0&&(j-1)>=0&&CheB[i-2][j-1]==0) {
//                i-=2;
//                j-=1;
//                CheB[i][j]=n*n-k+1;
//                step=3;
//                break;
//            }
//            }
//            case 4:{if((i-2)>=0&&(j+1)<n&&CheB[i-2][j+1]==0) {
//                i-=2;
//                j+=1;
//                CheB[i][j]=n*n-k+1;
//                step=4;
//                break;
//            }
//            }
//            case 5:{ if((i+1)<n&&(j-2)>=0&&CheB[i+1][j-2]==0) {
//                i+=1;
//                j-=2;
//                CheB[i][j]=n*n-k+1;
//                step=5;
//                break;
//            }
//            }
//            case 6:{if((i+1)<n&&(j+2)<n&&CheB[i+1][j+2]==0) {
//                i+=1;
//                j+=2;
//                CheB[i][j]=n*n-k+1;
//                step=6;
//                break;
//            }
//            }
//            case 7:{if((i+2)<n&&(j-1)>=0&&CheB[i+2][j-1]==0) {
//                i+=2;
//                j-=1;
//                CheB[i][j]=n*n-k+1;
//                step=7;
//                break;
//            }}
//            case 8 :{if((i+2)<n&&(j+1)<=n&&CheB[i+2][j+1]==0) {
//                i+=2;
//                j+=1;
//                CheB[i][j]=n*n-k+1;
//                step=8;
//                break;
//            }}
//
//}
//简化版 用两个一维数组模拟骑士每步可走的向量
int m_x[8]={ 2, 1, -1, -2, -2, -1, 1, 2 };
int m_y[8]={1, 2, 2, 1, -1, -2, -2, -1 };
//递归解决函数
int solve(int ** CheB ,int _x,int _y,int k)
{   //存储下一步的位置(保留上一次的位置)!!!很重要,否则无法回溯
    int n_x,n_y;
    //成功终止条件
    if (k==n*n) {
        return 1;
    }
    for (int step=0; step<8; step++) {
        //判断下一步是否合法
        if(((_x+m_x[step])>=0&&(_x+m_x[step])<n&&(_y+m_y[step])>=0&&(_y+m_y[step])<n&&(CheB[_x+m_x[step]][_y+m_y[step]]==-1))
           ){
                n_x=_x+m_x[step];
                n_y=_y+m_y[step];
                CheB[n_x][n_y]=k;
            if(solve(CheB,n_x,n_y,k+1))
            {
//                cout<<"骑士🤴成功巡游找到公主👸\n"; //在递归函数中会输出很多次
                return 1;}
            else
                CheB[n_x][n_y]=-1;
        }}
    return 0;
}
//展示路线
void show_rout(int ** CheB,int n){
    cout<<"骑士的路线如下:\n";
    for (int i=0; i<n; i++) {
        for (int j=0; j<n; j++) {
            cout<<setw(2)<<CheB[i][j]<<' ';
        }
        cout<<'\n';
    }
}

//delete棋盘
void _delete(int ** CheB)
{
    
    for(int i=0;i<n;i++)
    {
        delete[] CheB[i];
    }
    delete [] CheB;
}

//前言菜单
void menu(){
    cout<<"NPC:\n一天有个帅气的骑士与公主两情相悦💏,于是向🫅请婚,国王出了一个难题:让骑士能够按规则巡游找到公主,若成功找到便允了这门婚事\n(即骑士巡游问题)";
    cout<<"请问您是否了解游戏规则?(yes or no)\n";
    string cho;
    cin>>cho;
    if (cho =="no") {
        cout<<"ok,一起来看看吧:骑士巡游问题:在n 行n 列的棋盘上(如n=5)，假设一位骑士(按象棋中 “ 马走日” 的行走法)从初始坐标位置(x1，y1)出发，要遍访(巡游)棋盘中的每一个位置一次。\n游戏";
    }
    else if (cho=="yes")
    {
        cout<<"不错,看来你对这个胸有成竹啊!快让我们开始见证您高超的技术吧~\n";
    }
    else
    {
        cout<<"您还有点子“皮”,看来你是了解规则了,一会儿失误了可别找借口:不知道规则!😠\n";
    }
    cout<<"正式开始:\n";
    cout<<"情敌part:\n国王会想起他当年曲折的提亲之路,为了检验骑士的决心,便调皮地找到骑士的情敌查尔斯王子来决定地图的大小(n*n),现在请查尔斯决定其规格(N)\n尊贵的王子请输入:\n";
    input:
    cin>>n;
    if (n<0) {
        cout<<"能理解你爱而不得的哀伤,但是负数阶的棋盘有点离大谱吧~❓\n请再次输入:\n";
        goto input;
    }
    else if(n<5)
    {
        cout<<"公子您心胸真宽广,出得这么简单,小于5阶傻子都能找的到,再上点强度吧!\n再来一次 :";
        goto input;

    }
    else if(n>7)
    {
        cout<<"王子,有点狠啊,都高于7阶了,这样做天下人会笑您心胸狭窄的\n放点水再来一次吧:\n";
        goto input;
    }
    cout<<"狗头军师part:\n作为骑士的狗头军师的您请为他出谋划策为他找到合适的出发点,have a try,输入你的心仪坐标(x,y)!\n";
    cout<<"请注意地图的范围"<<'('<<0<<','<<0<<")~("<<n-1<<','<<n-1<<')'<<endl;
    n:
    cin>>x>>y;
    if(x<0||x>n||y<0||y>n)
    {
        cout<<"你是不是也暗恋公主,您输入的位置在地图之外😺,再给你一次机会!\n请输入:\n";
        goto n;
    }
}

int main() {
    menu();
 //new并初始化棋盘
    int **CheB=new int*[n]; //动态分配二维数组,模拟棋盘
    //初始化棋盘,-1的位置标志未走过
    for(int i=0;i<n;i++)
    {
        CheB[i]=new int[n];
    }
    for (int i=0; i<n; i++) {
        for (int j=0; j<n; j++) {
            CheB[i][j]=-1;
        }}
    
    CheB[x][y]=0;
    if(solve(CheB,x,y,1))
    {  cout<<"骑士🤴成功巡游找到公主👸\n";
        show_rout( CheB, n);}
    else
        cout<<"骑士没有成功巡游,公主run了~💔\n";
    _delete(CheB);
    return 0;
}
