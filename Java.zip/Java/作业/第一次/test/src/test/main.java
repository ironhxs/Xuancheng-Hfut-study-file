package test;
public class main {
		system.out.print("hello");
}
