package 第一次作业;

public interface Land {
	public void Is_Land() ;
}
