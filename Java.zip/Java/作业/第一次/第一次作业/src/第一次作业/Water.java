package 第一次作业;

public interface Water {
	public void Is_Water() ;
}
