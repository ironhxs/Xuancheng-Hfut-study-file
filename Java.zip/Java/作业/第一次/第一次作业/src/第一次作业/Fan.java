package 第一次作业;

public class Fan {
final int SLOW=1;
final int MEDIUM=2;
final int FAST=3;
private int speed ;
private boolean on;
private double radius;
String color;
public int get_speed() {
	return speed;
}
public boolean get_on() {
	return on;
}
public double get_radius() {
	return radius;
}
public String get_color() {
	return color;
}
public void set_speed(int a) {
	 speed=a;
}
public void set_on(boolean a) {
	 on=a;
}
public void set_radius(double a) {
	 radius=a;
}
public void set_color(String a) {
	color=a;
}
Fan(){
	speed =SLOW;
	 on=false;
	radius= 5;
	color="blue";
};
Fan(int a,boolean b,double c,String d){
	speed=a;
	on=b;
	radius=c;
	color=d;
}
public String toString() {
	String b = "hello";
	String speeds=" ";
	switch (speed) {
	case 1:
		speeds="SLOW";
		break;
	case 2:
		speeds="MEDIUM";
		break;
	case 3:
		speeds="FAST";
		break;
	}
	if(on) {
		b=("speed:"+speeds+" color:"+color+" radius:"+radius);
	}
	else {
		b=("color:"+color+" radius:"+radius+"   state:"+"fan is off");
	}
	return b;
}
}
