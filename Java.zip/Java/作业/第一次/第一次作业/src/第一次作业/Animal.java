package 第一次作业;

public abstract class Animal implements Water ,Land {
	public abstract void Feed_Hab();
	public abstract void Repro_Mode();
	public abstract void Greet_Mode();
	public abstract void Emo_Respon();
}
