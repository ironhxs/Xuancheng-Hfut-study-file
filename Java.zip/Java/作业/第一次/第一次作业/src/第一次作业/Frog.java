package 第一次作业;

public class Frog extends Animal {
	@Override
	public void Feed_Hab() {
		// TODO 自动生成的方法存根
		System.out.print("非肉食性");
	}

	@Override
	public void Repro_Mode() {
		// TODO 自动生成的方法存根
		System.out.print("卵生(非哺乳类)");
	}

	@Override
	public void Emo_Respon() {
		// TODO 自动生成的方法存根
		System.out.print("情绪好:呱呱呱唱歌\n惊吓时:扑通一声跳入水中");
	}

	@Override
	public void Greet_Mode() {
		// TODO 自动生成的方法存根
		System.out.print("青蛙王子高冷捏(不与人打招呼)");
	}

	@Override
	public void Is_Water() {
		// TODO 自动生成的方法存根
		System.out.print("青蛙是两栖动物");
	}

	@Override
	public void Is_Land() {
		// TODO 自动生成的方法存根
		System.out.print("青蛙是两栖动物");
	}

}
