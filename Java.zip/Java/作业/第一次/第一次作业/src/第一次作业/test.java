package 第一次作业;

public class test {
	public static  void main(String[]args) {
	Fan fan1=new Fan(3,true,10,"yellow");
	Fan fan2=new Fan(2,false,5,"blue");
	System.out.println("第一台风扇的状态:");
	System.out.print(fan1.toString()+"\n");
	System.out.println("第二台风扇的状态:");
	System.out.print(fan2.toString());
}
}
