package 第一次作业;

public class Cat extends Animal {
	@Override
	public void Feed_Hab() {
		// TODO 自动生成的方法存根
		System.out.print("肉食性");
	}

	@Override
	public void Repro_Mode() {
		// TODO 自动生成的方法存根
		System.out.print("哺乳类");
	}

	@Override
	public void Emo_Respon() {
		// TODO 自动生成的方法存根
		System.out.print("情绪好:咕噜咕噜\n惊吓烦躁时:嘶嘶");
	}

	@Override
	public void Greet_Mode() {
		// TODO 自动生成的方法存根
		System.out.print("喵~来招呼");
	}

	@Override
	public void Is_Land() {
		// TODO 自动生成的方法存根
		System.out.print("猫是陆生动物");
	}

	@Override
	public void Is_Water() {
		// TODO 自动生成的方法存根
		System.out.print("猫不是水生动物");
	}
}
