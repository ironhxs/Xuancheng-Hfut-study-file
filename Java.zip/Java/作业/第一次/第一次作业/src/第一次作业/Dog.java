package 第一次作业;

public class Dog extends Animal {

	@Override
	public void Feed_Hab() {
		// TODO 自动生成的方法存根
		System.out.print("肉食性");
	}

	@Override
	public void Repro_Mode() {
		// TODO 自动生成的方法存根
		System.out.print("哺乳类");
	}

	@Override
	public void Emo_Respon() {
		// TODO 自动生成的方法存根
		System.out.print("情绪好:汪汪叫\n惊吓烦躁时:呜呜叫");
	}

	@Override
	public void Greet_Mode() {
		// TODO 自动生成的方法存根
		System.out.print("摇摇尾巴打招呼");
	}

	@Override
	public void Is_Land() {
		// TODO 自动生成的方法存根
		System.out.print("狗是陆生动物");
	}

	@Override
	public void Is_Water() {
		// TODO 自动生成的方法存根
		System.out.print("狗不是水生动物");
	}

}
