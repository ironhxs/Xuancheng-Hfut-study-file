#include <iostream>
#include <vector>
#include <climits>

using namespace std;

const int INF = INT_MAX;

// Prim 算法
void prim(const vector<vector<int>>& graph, int n) {
    vector<int> key(n, INF);  // 用于存储当前节点的最小边权重
    vector<bool> inMST(n, false);  // 标记节点是否已加入生成树
    vector<int> parent(n, -1);  // 用于存储每个节点的父节点

    key[0] = 0;  // 从第一个节点开始
    int total_cost = 0;  // 总权重

    for (int count = 0; count < n - 1; ++count) {
        int u = -1;

        // 选择未加入生成树且 key 最小的节点
        for (int i = 0; i < n; ++i) {
            if (!inMST[i] && (u == -1 || key[i] < key[u])) {
                u = i;
            }
        }

        inMST[u] = true;  // 将节点加入生成树
        total_cost += key[u];  // 累加权重

        // 更新与 u 相邻节点的 key 值
        for (int v = 0; v < n; ++v) {
            if (graph[u][v] != INF && !inMST[v] && graph[u][v] < key[v]) {
                key[v] = graph[u][v];
                parent[v] = u;
            }
        }
    }

    // 输出最小生成树的边和总权重
    cout << "最小生成树的边：" << endl;
    for (int i = 1; i < n; ++i) {
        cout << "(" << parent[i] + 1 << ", " << i + 1 << ")" << endl;  // 输出边，索引从 1 开始
    }
    cout << "最小油管总长度： " << total_cost << " km" << endl;
}

int main() {
    // 邻接矩阵表示油井间的距离
    vector<vector<int>> graph = {
        {0, 1, 2, 0, 0, 1, 2, 1},
        {1, 0, 1, 2, 1, 3, 2, 1},
        {2, 1, 0, 3, 2, 3, 2, 1},
        {0, 2, 3, 0, 1, 2, 2, 1},
        {0, 1, 2, 1, 0, 1, 1, 1},
        {1, 3, 3, 2, 1, 0, 1, 1},
        {2, 2, 2, 2, 1, 1, 0, 1},
        {1, 1, 1, 1, 1, 1, 1, 0}
    };

    int n = graph.size();
    prim(graph, n);

    return 0;
}
