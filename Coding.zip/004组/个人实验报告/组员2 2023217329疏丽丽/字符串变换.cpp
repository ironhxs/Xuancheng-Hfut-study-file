#include<iostream>
#include<vector>
#include<string>
using namespace std;

int get_min(int a, int b, int c) {
    return min(min(a, b), c);
}

void print_steps(const string& s1, const string& s2, const vector<vector<int> >& a, const vector<vector<char> >& steps) {
    int i = s1.length();
    int j = s2.length();
    while (i > 0 || j > 0) {
        char step = steps[i][j];
        if (step == 'C') {
            cout << "Replace '" << s1[i-1] << "' with '" << s2[j-1] << "'" << endl;
            --i;
            --j;
        } else if (step == 'D') {
            cout << "Delete '" << s1[i-1] << "'" << endl;
            --i;
        } else if (step == 'I') {
            cout << "Insert '" << s2[j-1] << "'" << endl;
            --j;
        } else {
            --i;
            --j;
        }
    }
}

void get_way(const string& s1, const string& s2, vector<vector<int> >& a, vector<vector<char> >& steps) {
    int i, j;
    int con, del, ins, sub;
    a[0][0] = 0;
    for (i = 1; i <= s1.length(); i++) {
        a[i][0] = i;
    }
    for (j = 1; j <= s2.length(); j++) {
        a[0][j] = j;
    }
    for (i = 1; i <= s1.length(); i++) {
        for (j = 1; j <= s2.length(); j++) {
            if (s1[i-1] == s2[j-1]) {
                con = 0;
                steps[i][j] = 'M'; // M for match
            } else {
                con = 1;
                steps[i][j] = ' ';
            }
            del = a[i-1][j] + 1;
            ins = a[i][j-1] + 1;
            sub = a[i-1][j-1] + con;
            int min_val = get_min(del, ins, sub);
            a[i][j] = min_val;
            if (min_val == del) {
                steps[i][j] = 'D';
            } else if (min_val == ins) {
                steps[i][j] = 'I';
            } else if (min_val == sub && steps[i][j] == ' ') {
                steps[i][j] = 'C';
            }
        }
    }
    cout << "The least times: " << a[s1.length()][s2.length()] << endl;
    print_steps(s1, s2, a, steps);
}

int main(void) {
    string s1, s2;
    cout << "Input the first string" << endl;
    cin >> s1;
    cout << "Input the second string" << endl;
    cin >> s2;

    vector<vector<int> > a(s1.length() + 1, vector<int>(s2.length() + 1));
    vector<vector<char> > steps(s1.length() + 1, vector<char>(s2.length() + 1));
    get_way(s1, s2, a, steps);
    return 0;
}
