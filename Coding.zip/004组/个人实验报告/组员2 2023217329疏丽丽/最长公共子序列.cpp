#include<iostream>
#include<vector>
#include<string>
using namespace std;

// ���������ҵ�����������еĳ��ȣ����洢���������е�·��
void findLCS(const string& s1, const string& s2, vector<vector<int> >& dp, string& lcs) {
    int m = s1.length();
    int n = s2.length();

    // ��ʼ��DP��
    for (int i = 0; i <= m; i++) {
        dp[i][0] = 0;
    }
    for (int j = 0; j <= n; j++) {
        dp[0][j] = 0;
    }

    // ���DP��
    for (int i = 1; i <= m; i++) {
        for (int j = 1; j <= n; j++) {
            if (s1[i - 1] == s2[j - 1]) {
                dp[i][j] = dp[i - 1][j - 1] + 1;
            } else {
                dp[i][j] = max(dp[i - 1][j], dp[i][j - 1]);
            }
        }
    }

    // �����ҵ�LCS
    int index = dp[m][n];
    lcs.resize(index);
    int i = m, j = n;
    while (i > 0 && j > 0) {
        if (s1[i - 1] == s2[j - 1]) {
            lcs[index - 1] = s1[i - 1];
            i--;
            j--;
            index--;
        } else if (dp[i - 1][j] > dp[i][j - 1]) {
            i--;
        } else {
            j--;
        }
    }
}

int main(void) {
    string s1, s2;
    cout << "Input the first string:" << endl;
    getline(cin, s1);
    cout << "Input the second string:" << endl;
    getline(cin, s2);

    vector<vector<int> > dp(s1.length() + 1, vector<int>(s2.length() + 1));
    string lcs;
    findLCS(s1, s2, dp, lcs);

    cout << "The length of the longest common subsequence is: " << lcs.length() << endl;
    cout << "The longest common subsequence is: " << lcs << endl;
    return 0;
}
