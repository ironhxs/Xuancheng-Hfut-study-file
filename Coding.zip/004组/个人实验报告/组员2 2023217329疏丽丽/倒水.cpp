#include<iostream>
#define maxlen 100
using namespace std;

int aw=0,bw=0;
int times=0;
int av[maxlen],bv[maxlen];
void put_water(int a,int b,int l)
{
    if(aw==l || bw==l)
    {
        for(int i=0;i<times;i++)
        {
            cout<<av[i]<<"\t"<<bv[i]<<"\n";
        }
        return;
    }
    else if(aw==0)
    {
        aw = a;
        av[times] = aw;
        bv[times] = bw;
    }
    else if(aw!=0 && bw==0)
    {
        bw = aw;
        aw = 0;
        av[times] = aw;
        bv[times] = bw;
    }
    else if(aw!=0 && bw!=0)
    {
        int sum=bw+aw;
        if(sum>b)
        {
            bw = b;
            aw = sum-b;
        }
        else
        {
            bw = sum;
            aw = 0;
        }
        av[times] = aw;
        bv[times] = bw;
    }

    times++;
    if(times>100)
    {
        cout<<"No Solution"<<endl;
        return;
    }
    put_water(a,b,l);
}

int main(void)
{
    int a,b,l;
    cout<<"�������������ݻ���Ҫ���ˮ��������С��������ǰ����������ں�\n";
    cin>>a>>b>>l;

    if(l>a+b || a==b)
    {
        cout<<"No Solution"<<endl;
        return 0;
    }
    put_water(a,b,l);
    return 0;
}


