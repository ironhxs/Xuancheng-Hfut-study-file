﻿#include <iostream>
#include <vector>
#include <queue>
#include <unordered_map>
#include <iomanip>
#include <unordered_set>
#include <tuple>
#include <list>
using namespace std;
//组长 EFK
namespace E 
{
    //题目
   /* E题
    在某市有 n 个路口，每个路口都连接着另外两个路口，可以向方向 X 行走到
        达某个路口，或向方向 Y 行走到达某个路口（可能相同也可能回到原地），所有
        的路口被分为两种类型（用 0 / 1 表示），路口编号为 0 到 n - 1。现在以“路口独特
        度”指标评价该市的城市规划合理性。从 A 和 B 两个路口出发，一直按照同样
        的方向模拟从 A 路口出发和从 B 路口出发走，直到走到种类不同的路口，所需
        要的最短步数就是“路口独特度”。现在，给出该市的地图，请求出“路口独特
        度”。
        输入说明：
        输入包含多组数据，第一行输入数据组数 T。每组数据的输入如下：
        第一行三个正整数： n, A, B（ A≠B）
        第二行到第 n + 1 行每行三个整数： xi, yi, ti，表示路口 i 向方向 X 走到达路口 xi，
        向方向 Y 走到达路口 yi，它的种类为 ti。
        输出说明：
        如果能够判断，则输出最少步数，否则输出 GG
        输入样例：
        2
        3 1 2
        1 2 1
        0 2 0
        0 1 0
        3 1 2
        1 2 0
        2 0 1
        0 1 1
        样例输出：
        GG
        1*/
    // 自定义哈希函数
    struct TupleHash {
        std::size_t operator()(const std::tuple<int, int, int>& t) const {
            // 使用 std::get 获取元组中的元素
            int a = std::get<0>(t);
            int b = std::get<1>(t);
            int c = std::get<2>(t);

            // 结合各个字段的哈希值
            std::size_t h1 = std::hash<int>{}(a);
            std::size_t h2 = std::hash<int>{}(b);
            std::size_t h3 = std::hash<int>{}(c);

            return h1 ^ (h2 << 1) ^ (h3 << 2); // 合并哈希值
        }
    };

    // 自定义比较函数
    struct TupleEqual {
        bool operator()(const std::tuple<int, int, int>& t1, const std::tuple<int, int, int>& t2) const {
            // 比较两个元组的元素是否相等
            return t1 == t2;
        }
    };
   //定义的路口结构体
    struct Intersection {
        int xi;
        int yi;
        int type;
        Intersection(int x, int y, int t) : xi(x), yi(y), type(t) {}
        bool operator!=(const Intersection& other) const {
            return (xi != other.xi || yi != other.yi || type != other.type);
        }
    };
    //最小步数的全局计数
    int minStepCount = INT_MAX;
    //路口的集合
    vector<Intersection> Set;
    //状态的visited记录
    std::unordered_set<std::tuple<int, int, int>, TupleHash, TupleEqual> visited;
    // 遍历和递归的深度优先搜索函数
    void GO(int step_count, int way1, int way2,int choice) {
        // 打印调试信息，查看递归过程
        std::cout << "Recursion with step_count: " << step_count
            << ", way1: (" << Set[way1].xi << ", " << Set[way1].yi << "), type: " << Set[way1].type
            << ", way2: (" << Set[way2].xi << ", " << Set[way2].yi << "), type: " << Set[way2].type << std::endl;

        // 如果已经找到更短的路径或这个状态访问过了，不再继续递归
        tuple<int, int, int> current = std::make_tuple(way1, way2, choice);
        if (step_count >= minStepCount||visited.find(current) != visited.end()) {
            return;
        }
        visited.insert(current);
        // 终止条件：两路口的类型不同
        if (Set[way1].type != Set[way2].type) {
            minStepCount = step_count;
            return;
        }

        // 递归尝试不同的路口组合，防止无效递归
        if (Set[way1].xi >= 0 && Set[way1].xi < Set.size() && Set[way2].xi >= 0 && Set[way2].xi < Set.size()) {
                GO(step_count + 1, Set[way1].xi, Set[way2].xi,0);
                GO(step_count + 1, Set[way1].yi, Set[way2].yi,1);
        }
    }
    //综合解决函数
    void test() {
        int T, n, A, B;
        int x, y, t;
        std::vector<int> answer;

        std::cout << "请输入组数" << std::endl;
        std::cin >> T;

        for (int i = 0; i < T; ++i) {
            Set.clear();
            minStepCount = INT_MAX;
            visited.clear();
            std::cout << "请输入第" << i + 1 << "组数据" << std::endl;
            std::cin >> n >> A >> B;

            std::cout << "请依次输入各个路口参数" << std::endl;
            for (int j = 0; j < n; ++j) {
                std::cin >> x >> y >> t;
                Set.emplace_back(x, y, t);
            }

            // 调用 solution 进行递归计算
            GO(0, A, B,-1);
            answer.push_back(minStepCount);
        }

        std::cout << "输出结果：" << std::endl;
        for (const auto& result : answer) {
            if (result != INT_MAX) {
                std::cout << result << std::endl;
            }
            else {
                std::cout << "GG" << std::endl;
            }
        }
    }
}
namespace F
{
   //题目：
       /* 现在，科研人员想要研发新的太阳能板材料，在 n 个仓库中存放了 n 种原始
        材料，有 n - 1 条道路将这 n 个仓库连接在一起，每条道路连接着两个仓库，进行
        新材料的合成必须使用两种原始材料。考虑到运输成本和材料成本，只能选择被
        一条道路直接相连的两个仓库中的原始材料进行合成， 且每种原始材料只能被使
        用一次。在两种原始材料合成之后，得到的新材料的吸光能力为两种原始材料的
        吸光能力之乘积。现在科研人员想要知道，合成的新材料的吸光能力的总和最大
        是多少。
        输入说明：
        第一行一个正整数： n
        第二行到第 n 行每行两个整数： ai, bi 表示仓库 ai 和仓库 bi 之间存在道路，
        第 n + 1 行 n 个正整数： vi，表示仓库 i 中的原始材料的吸光能力
        输出说明：
        能够得到的最大的吸光能力总和。
        输入样例：
        5
        1 2
        1 3
        2 4
        2 5
        1 2 3 4 5
        输出样例：
        13*/
    // 自定义 pair<int, int> 的哈希函数
    struct PairHash {
        size_t operator()(const pair<int, int>& p) const {
            return hash<int>()(p.first) ^ (hash<int>()(p.second) << 1);
        }
    };
    //仓库个数
    int N;
    //全局大值
    int maxSum=INT_MIN;
    //仓库链表以及相邻关系
    vector<list<int>> storeList;
    //材料表
    unordered_map<pair<int, int>, int, PairHash> materials;
    //标记数组
    vector<bool> used;
    //递归回溯解决函数
    void solution(int cnt, int sum)
    {
        //打印调试信息
        cout <<cnt<<':' << sum << endl;
        //结束条件判断
        if (cnt == N-1)
            return;
        //判断是否使用过了
        if (used[cnt])
        {
            solution(cnt + 1, sum);
            return;
        }
        //动态更新，分状态最优递归下来就是全局最优
        int temp = maxSum;
        maxSum = sum > maxSum ? sum : maxSum;
        used[cnt] = true;
        // 从 storeList[cnt] 的第二个元素开始循环递归从而达到全遍历
        for (auto it = next(storeList[cnt].begin()); it != storeList[cnt].end(); ++it)
        {
            int elem = *it;
            auto material_it = materials.find(make_pair(cnt, elem));
            if (!used[elem] && material_it != materials.end())
            {
                used[elem] = true;
                solution(cnt + 1, sum + material_it->second);
                used[elem] = false;
            }
        }
        //回溯
        used[cnt] = false;
        maxSum = temp;
    }
    //综合解决调用函数
    void test()
    {
        //输入处理
        cout << "输入仓库个数:\n";
        cin >> N;
        used.resize(N, false);
        storeList.resize(N);
        cout << "请输入n-1条道路(ai bi)ai<bi:\n";
        for (size_t i = 0; i < N - 1; i++)
        {
            int t1, t2;
            cin >> t1 >> t2;
            storeList[t1-1].push_back(t2-1);
        }
        cout << "请输入" << N << "个仓库中材料的吸光能力:\n";
        for (size_t i = 0; i < N; i++)
        {
            int t;
            cin >> t;
            storeList[i].push_front(t);
        }
        cout  << "仓库中材料的吸光能力如下:\n";
        for (size_t i = 0; i < N; i++)
        {
            
            cout<<i+1<<':'<<storeList[i].front()<<"   ";
        }
        cout << endl;
        //构建材料表
        cout << "构建的材料表如下:\n";
        for (size_t i = 0; i < N; i++)
        {
            for (auto it =next(storeList[i].begin()); it != storeList[i].end(); it++)
            {
                    materials.emplace(make_pair(i, *it),(storeList[i].front()) * (storeList[*it].front()));
                    cout <<'(' << i+1<< ',' << *it+1 << ',' << (storeList[i].front()) <<'*'<< storeList[*it].front() << ')' << endl;
            }
        }
        //调用解决函数
        solution(0, 0);
        cout << "最大的吸光能力总和为：\n" << maxSum;
    }
}
namespace K 
{
    //优化可能遇到
//#include <unordered_set>
//#include <tuple>
//#include <memory>
//#include <functional>
    
//题目
  /*  K 公益活动
        一条从 1 到 ݊ 的数轴上有 ݉ 名志愿者。
        每名志愿者有一条行进路线，可以用三个整数  ݅݌, ܿ݅, ݅ݐ来描述第 ݅ 名志
        愿者的行进路线。
        具体来说，如果 ܿ݅ > 0，则第 ݅ 名志愿者会在  ݅ݐ时刻从  ݅݌点出发以每
        秒 1 单位长度的速度向 ݊ 号点方向出发前进 ܿ݅ 时刻后停下；如果 ܿ݅ < 0，
        则第 ݅ 名志愿者会在  ݅ݐ时刻从  ݅݌点出发以每秒 1 单位长度的速度向 1 号
        点方向出发前进 - ܿ݅ 时刻后停下。
        你要安排这些志愿者中的一部分来完成一些完成公益任务。第 ݅ 名志愿者
        仅在[| ]ܿ݅ | +݅ݐ, ݅ݐ时刻工作， 他可以在这段时间里的任意整数时刻交接任务。
        而志愿者能进行任务 i 的交付当且仅当在某一时刻两名志愿者位于同一个整点
        上。具体来说， ݅, ݆ 号志愿者可以在整数时刻 ，ݐ整点位置  ݌进行交接任务，
        当且仅当：
        其中 sgn(x) 为符号函数。
        现在你收到了  ݍ个任务需求，其中第 ݅ 份任务包含两个整数 ，݅ݔ, ݅ݓ表
        示这份任务希望你将任务在最晚  ݅ݓ时刻从 1 号点运送某些物品到  ݅ݔ号点，
        你想算出完成这项任务最少需要安排多少名志愿者。如果无解，即安排了所有志
        愿者也无法完成订单，则输出 - 1。注意这  ݍ份订单是相互独立的，所有志愿者
        每次都需要重新安排。
        输入说明：
        第一行包含两个整数 ݊, ݉ 表示数轴的长度及志愿者的数量。本科组试题册(2023)
        19 / 20
        接下来 m 行每行包括三个整数  ݅݌, ܿ݅, ݅ݐ描述该志愿者的运送路线。
        接下来一行一个整数  ݍ表示任务的数量。
        接下来  ݍ行每行两个整数  ݅ݔ, ݅ݓ表示这份任务要求的最晚时刻及送达地
        点。
        保证 1 ≤ ݊, ≤ ݅ݐ2000, 1 ≤ ݉ ≤ 106, 1≤  ≤ ݍ105，志愿者只在 1 到
        ݊ 的数轴上移动。
        输出说明：
        输出  ݍ行，其中第 ݅ 行包含一个整数表示完成第 ݅ 份订单最少需要安排
        多少名志愿者，或输出 - 1 表示任务无法完成。
        输入样例：
        10 10
        2 1 5
        5 4 3
        8 7 1
        9 8 2
        3 1 7
        6 3 6
        9 6 4
        6 2 8
        6 7 - 2
        10 8 - 8
        4
        11 10
        12 9
        13 10
        14 10*/
    int countNode = 0;
    struct Volunteer
    {
        int start_time; // 开始时间
        int start_pos;  // 起始位置
        int duration;   // 工作时间（正值向右，负值向左）

        Volunteer() : start_time(-1), start_pos(-1), duration(-1) {}

        Volunteer(int a, int b, int c) : start_time(a), start_pos(b), duration(c) {}

        // 确保可以拷贝
        Volunteer(const Volunteer&) = default;
        Volunteer& operator=(const Volunteer&) = default;

        bool operator==(const Volunteer& other) const {
            return (start_time == other.start_time &&
                start_pos == other.start_pos &&
                duration == other.duration);
        }

    };
    // 自定义哈希函数
    struct pair_hash
    {
        template <class T1, class T2>
        std::size_t operator () (const std::pair<T1, T2>& pair) const {
            auto hash1 = std::hash<T1>{}(pair.first);
            auto hash2 = std::hash<T2>{}(pair.second);
            return hash1 ^ (hash2 << 1);
        }

        template <class T1, class T2>
        bool operator () (const std::pair<T1, T2>& lhs, const std::pair<T1, T2>& rhs) const {
            return lhs.first == rhs.first && lhs.second == rhs.second;
        }
    };
    // 为 Volunteer 结构体定义哈希函数
    struct VolunteerHash
    {
        size_t operator()(const Volunteer& vol) const {
            return hash<int>()(vol.start_time) ^ hash<int>()(vol.start_pos) ^ hash<int>()(vol.duration);
        }
    };

    //// 为 tuple<int, int, int, Volunteer> 定义哈希函数
    //struct TupleHash {
    //    size_t operator()(const tuple<int, int, int, Volunteer>& t) const {
    //        const Volunteer& vol = get<3>(t); // 获取最后一个元素
    //        return hash<int>()(get<0>(t)) ^ hash<int>()(get<1>(t)) ^ hash<int>()(get<2>(t)) ^ VolunteerHash()(vol);
    //    }
    //};
    //
    //// 为 tuple<int, int, int, Volunteer> 定义相等比较器
    //struct TupleEqual {
    //    bool operator()(const tuple<int, int, int, Volunteer>& lhs, const tuple<int, int, int, Volunteer>& rhs) const {
    //        return get<0>(lhs) == get<0>(rhs) &&
    //            get<1>(lhs) == get<1>(rhs) &&
    //            get<2>(lhs) == get<2>(rhs) &&
    //            get<3>(lhs) == get<3>(rhs);
    //    }
    //};

    //各个模型
    struct Task
    {
        int target_pos;  // 目标位置
        int latest_time; // 最晚到达时间
    };

    struct State
    {
        int time;            // 当前时间
        int position;        // 当前位置信息
        int volunteers_used; // 使用的志愿者数量
    };

    struct StateNode
    {
        State state;
        Volunteer current_volunteer;
        //第一次遍历用于统计vu
        shared_ptr<StateNode> parent;
        //用于BFS找最少vu
        vector<shared_ptr<StateNode>> children;

        StateNode(int t = 0, int pos = 1, int vu = 0, Volunteer vol = Volunteer())
            : state{ t, pos, vu }, current_volunteer(vol), parent(nullptr) {
            children = {};
        }
    };

    class StateTree {
    public:
        //优化此root是虚拟根界点 用于放树林
        shared_ptr<StateNode> root;
        vector<shared_ptr<StateNode>> parents;
        StateTree() {
            root = make_shared<StateNode>(); // 初始化根节点
            root->state.position = 1;
            root->state.time = 0;
            root->state.volunteers_used = 0;
            root->current_volunteer = Volunteer();
            root->parent = nullptr;
            parents.resize(1, root);
            parents.resize(999, nullptr);
        }
        // 添加节点的函数
        void addNode(const StateNode& newState, std::shared_ptr<StateNode> temp = nullptr)
        {
            // 初始化 temp 节点，默认从根节点开始
            if (!temp)
            {
                temp = root;
            }
            //优化！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！
            if (newState.state.volunteers_used == 0)
            {
                auto newNode = std::make_shared<StateNode>(newState);  // 创建新节点
                //newNode->parent = root;  // 设置父节点
                root->children.push_back(newNode);  // 将新节点插入到父节点的子节点列表中
                //新深度需要添加标记
                parents[newState.state.volunteers_used + 1] = newNode;
                return;
            }
            //检查扩容
            if (newState.state.volunteers_used < parents.size())
            {
                //已经有过该深度的节点了
                if (parents[newState.state.volunteers_used])
                {
                    temp = parents[newState.state.volunteers_used];
                }

            }
            else
                parents.resize(newState.state.volunteers_used + 2 + 10, nullptr);
            // 检查是否找到深度匹配的父节点
            if (temp->state.volunteers_used == newState.state.volunteers_used - 1)
            {
                auto newNode = std::make_shared<StateNode>(newState);  // 创建新节点
                //newNode->parent = temp;  // 设置父节点
                temp->children.push_back(newNode);  // 将新节点插入到父节点的子节点列表中
                //新深度需要添加标记
                parents[newState.state.volunteers_used + 1] = newNode;
                return;
            }
            else
            {
                // 递归查找当前节点的所有孩子节点
                for (auto& child : temp->children) {
                    addNode(newState, child);  // 递归向下传递，继续查找
                }
            }
        }

        // BFS 搜索最小志愿者数的函数
        int bfsFindMin(Task t)
        {
            if (!root)
                return -1; // 如果树为空，直接返回

            queue<shared_ptr<StateNode>> q;
            q.push(root);

            while (!q.empty()) {
                auto current = q.front();
                q.pop();
                if (current->state.time <= t.latest_time && current->state.position == t.target_pos)
                {
                    auto temp = current;
                    cout << "解决方案的路径回溯如下:\n";
                    while (temp)
                    {
                        std::cout << "当前时间: " << temp->state.time << ", 位置: " << temp->state.position << ", 志愿者数量: " << temp->state.volunteers_used << "当前志愿者是：( 起始位置: " << temp->current_volunteer.start_pos
                            << ", 开始时间: " << temp->current_volunteer.start_time << ", 持续: " << temp->current_volunteer.duration << "] )\n";
                        temp = temp->parent;
                    }
                    return current->state.volunteers_used;
                }
                // 将当前节点的子节点加入队列
                for (auto& child : current->children)
                {
                    q.push(child);
                }
            }
            return -1;
        }
    };
    //递归回溯解决函数
    int Solution(int n, const vector<Volunteer>& volunteers, Task t)
    {
        // 使用unordered_map保存每个位置和时间对应的志愿者
        unordered_map<pair<int, int>, vector<Volunteer>, pair_hash> paths;
        // 构建志愿者的路径表
        for (const auto& vol : volunteers) {
            for (int i = vol.start_time; i <= min(vol.start_time + abs(vol.duration), t.latest_time); ++i) {
                int new_pos = vol.start_pos + (vol.duration > 0 ? (i - vol.start_time) : -(i - vol.start_time));
                if (new_pos >= 1 && new_pos <= n) {
                    paths[{new_pos, i}].push_back(vol); // 每个时间和位置可能有多个志愿者
                }
            }
        }

        //输出路径表用于测试
        //std::cout << std::left; // 左对齐
        //std::cout << std::setw(2) << "位置" << std::setw(2) << "时间" << "志愿者" << std::endl;
        //std::cout << std::string(30, '-') << std::endl; // 输出分隔线
        int cnt = 1;
      /*  for (const auto& entry : paths) {
            int position = entry.first.first;
            int time = entry.first.second;
            const auto& volunteers_at_pos = entry.second;
            std::cout<< cnt <<":" << std::setw(10) << position << std::setw(10) << time;
            cnt++;
            if (volunteers_at_pos.empty()) {
                std::cout << "无志愿者" << std::endl;
                continue;
            }
            for (const auto& vol : volunteers_at_pos) {
                std::cout <<"( 起始位置: " << vol.start_pos
                    << ", 开始时间: " << vol.start_time << ", 持续: " << vol.duration << "] )";
               
            }
            std::cout << std::endl;
        }*/

        //用于遍历的队列
        queue<shared_ptr<StateNode>> q;
        //等待构建BFS的状态树
        StateTree T;

        //可能的优化方案---标记不进行重复遍历处理
        //unordered_set<tuple<int, int, int, Volunteer>, TupleHash, TupleEqual> visited;

        // 初始化真实根节点并加入队列和状态树
        auto root = make_shared<StateNode>(0, 1, 0);
        root->current_volunteer = Volunteer();
        T.addNode(*root);
        q.push(root);
        //visited.insert({ root->state.position, root->state.time, root->state.volunteers_used, root->current_volunteer });
        while (!q.empty()) {
            shared_ptr<StateNode> current = q.front();
            //std::cout << "当前出队列节点的时间: " << current->state.time << ", 位置: " << current->state.position << ", 志愿者数量: " << current->state.volunteers_used << std::endl;
            q.pop();
            int max_wait_time = (t.latest_time - current->state.time) - abs(t.target_pos - current->state.position);
            if (max_wait_time < 0)
            {
                //不可能到达
                continue;
            }
            else
            {
                //可能
                for (size_t i = 0; i <= max_wait_time; i++)
                {
                    auto it = paths.find({ current->state.position, current->state.time + i });
                    if (it != paths.end())
                    {
                        for (const auto& vol : it->second)
                        {
                            /*std::cout << "当前时间: " << current->state.time+i << ", 位置: " << current->state.position << ", 志愿者数量: " << current->state.volunteers_used << "查找到的志愿者有：\n( 起始位置: " << vol.start_pos
                                << ", 开始时间: " << vol.start_time << ", 持续: " << vol.duration << "] )";*/
                            if (current->state.time + i - vol.start_time != abs(vol.duration))
                            {
                                //下一个状态节点
                                auto next_statenode = make_shared<StateNode>();

                                //更新下一个节点时间
                                next_statenode->state.time = current->state.time + 1 + i;
                                // 根据志愿者方向更新位置
                                if (vol.duration > 0)
                                {
                                    //cout << "正向跑\n";
                                    next_statenode->state.position = current->state.position + 1;
                                }
                                else if (vol.duration < 0)
                                {
                                    next_statenode->state.position = current->state.position - 1;
                                }
                                // 检查志愿者是否为新的使用，更新下一个节点的志愿者数
                                bool new_flag = true;
                                shared_ptr<StateNode> temp = current;
                                while (temp->parent) {
                                    if (vol == (temp->current_volunteer)) {
                                        new_flag = false;
                                        /*cout << "新的\n";*/
                                        break;
                                    }
                                    temp = temp->parent;
                                }
                                next_statenode->state.volunteers_used = current->state.volunteers_used + (new_flag ? 1 : 0);

                                //更新下一个节点的current_volunteer
                                next_statenode->current_volunteer = vol;
                                //更新下一个节点的parent
                                next_statenode->parent = current;

                                /*// 将状态作为键值判断是否访问过
                                auto state_key = make_tuple(next_statenode->state.position, next_statenode->state.time,
                                    next_statenode->state.volunteers_used, next_statenode->current_volunteer);
                                if (visited.find(state_key) == visited.end()) {
                                    visited.insert(state_key);*/
                                    //剪枝
                                if (next_statenode->state.time <= t.latest_time)
                                {
                                    //cout << "在限制时间内\n";
                                    q.push(next_statenode);
                                    T.addNode(*next_statenode);
                                    countNode++;
                                    //std::cout << "插入了时间: " << next_statenode->state.time << ", 位置: " << next_statenode->state.position << ", 志愿者数量: " << next_statenode->state.volunteers_used << std::endl;
                                }
                            }
                            else
                            {
                                //该志愿者不能动了
                                continue;
                            }
                        }

                    }
                }
            }
        }
        return T.bfsFindMin(t);
    }
    //综合解决函数
    void test()
    {
        int n, m;
        cin >> n >> m; // 输入场地数量和志愿者数量
        vector<Volunteer> volunteers(m);

        // 输入每个志愿者的信息
        for (int i = 0; i < m; ++i) {
            cin >> volunteers[i].start_time >> volunteers[i].start_pos >> volunteers[i].duration;
        }

        int q;
        cin >> q; // 输入任务数量
        vector<Task> tasks(q);

        // 输入每个任务的最晚到达时间和目标位置
        for (int i = 0; i < q; ++i) {
            cin >> tasks[i].latest_time >> tasks[i].target_pos;
        }

        // 对每个任务执行 BFS，找到最小志愿者数量
        for (const auto& task : tasks) {
            countNode = 0;
            cout << "任务:最晚到达时间: " << task.latest_time << "任务目标位置 : " << task.target_pos << endl;
            int min_volunteers = Solution(n, volunteers, task);
            if (min_volunteers != -1) {
                cout << "共有状态节点" << countNode << "个\n最小志愿者数: " << min_volunteers << endl << endl;
            }
            else {
                cout << " 最晚到达时间: " << task.latest_time << "任务目标位置: " << task.target_pos
                    << " 无法到达" << endl;
            }
        }
    }
}                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             

//组员1 DJ
namespace D
{
    //题目
  /*  这条道路可以看成一条直线，上面有 N 个和其
        他道路交错形成的路口， 每个相邻的路口之间可以安装装置宣传到经过此段道路
        的市民。由于装置的价值昂贵，所以不能在每个相邻的路口之间安装装置进行宣
        传，所以政府决定选定 k 个相邻的路口，在路口之间安装装置进行宣传。关于每
        天在每对路口之间通行的市民数量的统计数据已经知晓(假设每位市民每天只通
            行一次，且从一个路口进，一个路口出)。现在，政府需要知道在哪些路口之间
        安装装置可以使得最多市民受到宣传，促进可持续交通和减少碳排放。请你帮忙
        计算收到宣传的最大市民数是多少。
        输入说明：
        第一行包含两个整数 n, k ，表示道路经过的路口数和可以安装的装置数目。
        接下来 n −1 行， 每行包含 n i −(1 <= i <= n - 1)个整数， 其中第 j（1 <= j <= n - i）
        个数表示第 i 个路口到第 i j + 个路口之间的每天的通行市民数量。
        输出说明：
        第一行包含一个整数，表示能够收到宣传的市民最大总数。
        输入样例：
        4 1
        5 0 6
        5 3
        5
        输出样例：
        14*/
    const int MAXN = 510;
    int a[MAXN][MAXN];
    int dp[MAXN][MAXN];
    void test()
    {
        int n, k;
        cin >> n >> k;//表示路口的数量和需要选择的路口数量

        // 读取输入
        for (int i = 1; i < n; ++i) {
            for (int j = 1; j <= n - i; ++j) {
                cin >> a[i][i + j];
            }
        }//读取输入数据，填充数组 a。a[i][i + j] 表示从路口 i 到路口 i + j 之间的市民数量

        // 预处理每对路口之间的市民数量和
        for (int i = 1; i <= n; ++i) {
            for (int j = n - 1; j > i; --j) {
                a[i][j] += a[i][j + 1];//路口之后市民的累加
            }
        }
        for (int j = n; j > 0; --j) {
            for (int i = n - 1; i > 0; --i) {
                a[i][j] += a[i + 1][j];
            }
        }

        // 动态规划计算最大市民数量和
        for (int j = 1; j <= k; ++j) {
            for (int i = n - j; i > 0; --i) {
                for (int m = i + 1; m <= n; ++m) {
                    dp[i][j] = max(dp[i][j], dp[m][j - 1] + a[i][m]);
                }
            }
        }

        cout << dp[1][k] << endl;//从路口1开始选择K个路口，使得市民数量和最大

    }
}
namespace J
{
    //题目
        /*科研人员基于该可再生能源发明了一种发电装置，该装置有
        n 个能源槽位，第 i 个能源槽位中放入了 i 份新能源。该发电装置的能源槽位的
        位置可以进行随意交换，但是，对于其中任意一对能源槽位，只有满足当且仅当
        这两个能源槽位的位置编号互质且其中的新能源量互质， 这种情况下发电装置才
        能得到最大的发电功率。
        现在，发电装置的能源槽位已经被进行了一些交换，而其中一些能源槽位中
        的新能源量已知，科研人员想要知道有多少种方案可以得到最大的发电功率，结
        果对 1e9 + 7 取模。
        输入说明：
        输入包含多组数据，第一行输入数据组数 T
        每组数据的输入如下：
        第一行一个正整数 n；第二行 n 个数 a1, a2, …, an；若 ai = 0 则这个槽位的新能源量
        未知，否则代表该槽位的新能源量。
        输出说明：
        满足条件的方案个数，对 1e9 + 7 取模。
        样例输入 1：
        1
        4
        0 0 0 0
        样例输出 1：
        4
        样例输出 2：
        2
        5
        0 0 1 2 0
        6
        0 0 1 2 0 0
        样例输出 2：
        2
        0*/
    const int MOD = 1e9 + 7;
    // 计算最大公约数
    int gcd(int a, int b) {
        return b == 0 ? a : gcd(b, a % b);
    }

    // 判断两个数是否互质
    bool isCoprime(int a, int b) {
        return gcd(a, b) == 1;
    }

    bool isValid(int pos, int val, const vector<int>& current, const vector<int>& fixed) {
        // 检查已经固定的值,是否匹配
        if (fixed[pos] != 0 && fixed[pos] != val) return false;

        // 检查新位置与之前所有位置的互质性
        for (int i = 0; i < pos; i++) {
            if (current[i] == 0) continue;

            // 检查位置编号是否互质
            if (!isCoprime(pos + 1, i + 1)) {
                if (isCoprime(current[i], val)) return false;
            }
            else {
                if (!isCoprime(current[i], val)) return false;
            }
        }
        return true;
    }

    void backtrack(int pos, int& count, int n, vector<int>& current, vector<bool>& used, const vector<int>& fixed) {
        if (pos == n) {
            count = (count + 1) % MOD;
            return;
        }

        // 如果当前位置已经有固定值，递归下一个
        if (fixed[pos] != 0) {
            if (isValid(pos, fixed[pos], current, fixed)) {
                current[pos] = fixed[pos];
                backtrack(pos + 1, count, n, current, used, fixed);
            }
            return;
        }
        //回溯算法
            // 尝试所有可能的值
        for (int i = 1; i <= n; i++) {
            if (!used[i] && isValid(pos, i, current, fixed)) {
                used[i] = true;
                current[pos] = i;
                backtrack(pos + 1, count, n, current, used, fixed);
                used[i] = false;
                current[pos] = 0;
            }
        }
    }

    int solve(int size, const vector<int>& nums) {
        int n = size;
        vector<int> fixed = nums;
        vector<bool> used(n + 1, false);
        vector<int> current(n, 0);
        int count = 0;

        // 标记已经使用的固定值
        for (int i = 0; i < n; i++) {
            if (nums[i] != 0) {
                if (used[nums[i]]) return 0; // 如果固定值有重复，无解
                used[nums[i]] = true;
            }
        }

        backtrack(0, count, n, current, used, fixed);
        return count;
    }
    void test()
    {
        int T;
        cin >> T;

        while (T--) {
            int n;
            cin >> n;
            vector<int> nums(n);
            for (int i = 0; i < n; i++) {
                cin >> nums[i];
            }

            cout << solve(n, nums) << endl;
        }

    }
}

//组员2 BH
namespace B
{
    //题目
    /*有一天，小 C 梦到了许多神奇的数排列组成的神奇数列，定义如下：如果一
        个正整数 n 可以被表示成 a2 - b2 = n （a, b 均为正整数， 那么 n 则被小 C 称为神奇数。 ）
        当小 C 醒来后，他意识到神奇数列与环境保护有着紧密的联系。每个神奇数都
        代表着一种特殊的环境保护措施， 而神奇数列则是这些措施按照从小到大的顺序
        排列。
        小 C 决定将神奇数列重新定义为"环保数列"， 并将每个数值与相应的环保行
        动联系起来。以下是环保数列的前几项：
        第一项： 3（环保行动：节约用水）
        当 a = 2， b = 1 时，有 3 = 2 ^ 2 - 1 ^ 2，因此 3 是神奇数，代表节约用水。
        第二项： 5（环保行动：减少碳排放）
        当 a = 3， b = 2 时，有 3 = 3 ^ 2 - 2 ^ 2，因此 5 是神奇数，代表减少碳排放。
        第三项： 7（环保行动：推广可再生能源）
        当 a = 4， b = 3 时，有 7 = 4 ^ 2 - 3 ^ 2，因此 7 是神奇数，代表推广可再生能
        源。
        第四项： 8（环保行动：垃圾分类）
        当 a = 3， b = 1 时，有 8 = 3 ^ 2 - 1 ^ 2，因此 8 是神奇数，代表垃圾分类。
        …..
        小 C 感到振奋，意识到他可以用这个环保数列来激励自己和他人采取更多
        的环保行动。他深信环保数列中的每个数值都代表着一种有益的环保实践，通过
        传播这个概念，他可以帮助更多人意识到环境保护的重要性。
        现在，小 C 希望你告诉他环保数列某一项的值。
        输入说明：
        第一行一个整数 T（ 1 <= T <= 10），表示数据组数；
        对于每组数据，输入一行一个整数 x（ 1 <= x <= 109），表示询问的项数。
        输出说明：
        对于每组数据，输出一行一个整数，表示题述定义的神奇数列第 x 项的值。
        输入样例：
        2
        4
        6
        输出样例：
        8
        11*/
    void test()
    {
        int T;
        cin >> T;
        long long a[10];
        for (int i = 0; i < T; i++) {
            cin >> a[i];
        }
        for (int i = 0; i < T; i++) {
            long long m = a[i] / 3;
            int n = a[i] % 3;

            if (a[i] == 1) cout << 3 << endl;
            else if (n == 1) cout << (m + 1) * 4 << endl;
            else if (n == 2) cout << (m + 1) * 4 + 1 << endl;
            else if (n == 0) cout << (m + 1) * 4 - 1 << endl;
        }

    }
}
namespace H
{
    //题目
        /*该系统包括发电站、 输电站和变电站等站点和一套输电线路，
        用于将电力从一个地方输送到另一个地方。每个站点都被编号：发电站的编号为
        1，变电站的编号为 N，中间的输电站的编号从 2 到 N - 1。沿途的每段输电线路连
        接一对输电站，每条输电线路可以向任意方向输送有限数量的电力。
        中国西电公司聘请你作为输电系统规划师，帮助设计该输电系统。你需要根
        据地图和输电线路容量，计算该输电系统最多可以输送多少电力。
        输入说明：
        第一行包含两个个整数 N M, ，其中 N 表示发电站、输电站和变电站等站点
        数量之和，M 表示站点间的输电线路数量。 2 10000 ≤ ≤ N 。接下来的 M 行描述
        了输电线路的规格：对于每条输电线路，三个数字描述连接它的一对站点以及其
        输电容量 1 到108 的整数。保证输送的电量不会是负数。
        输出说明：
        只有一行，在第一行输出可以输送的最大电力数量。
        输入样例：
        3 2
        1 2 2
        2 3 1
        输出样例：
        1*/
    // 定义最大节点数
    const int MAXN = 10000 + 5;

    // 全局变量，存储节点数和边数
    int n, m;

    // 存储每条边的容量
    int capacity[MAXN][MAXN];

    // 存储当前流
    int flow[MAXN][MAXN];

    // 用于记录前一个节点，以便追溯路径
    int prev[MAXN];

    // 访问标记数组，用于BFS
    bool visited[MAXN];

    // 使用BFS实现的Ford-Fulkerson算法的函数，用于寻找增广路径
    int bfs(int src, int dest) {
        // 初始化访问标记数组
        fill(visited, visited + n, false);
        queue<int> q;
        q.push(src);
        visited[src] = true;

        while (!q.empty()) {
            int u = q.front();
            q.pop();

            // 遍历所有邻居节点
            for (int v = 0; v < n; v++) {
                // 如果邻居未被访问，并且有剩余容量
                if (!visited[v] && capacity[u][v] - flow[u][v] > 0) {
                    // 记录路径和访问标记
                    prev[v] = u;
                    visited[v] = true;
                    q.push(v);

                    // 如果找到增广路径到汇点
                    if (v == dest) {
                        return min(capacity[u][v] - flow[u][v], INT_MAX - 1);
                    }
                }
            }
        }
        // 如果没有找到增广路径
        return 0;
    }

    // 实现Ford-Fulkerson算法的函数，用于计算最大流
    int maxFlow(int src, int dest) {
        int total_flow = 0;
        // 循环直到找不到增广路径
        while (int new_flow = bfs(src, dest)) {
            total_flow += new_flow;
            // 沿着增广路径更新流
            int cur = dest;
            while (cur != src) {
                int prev_node = prev[cur];
                flow[prev_node][cur] += new_flow;
                flow[cur][prev_node] -= new_flow;
                cur = prev_node;
            }
        }
        return total_flow;
    }
    void test()
    {
        // 读取节点数和边数
        cin >> n >> m;
        // 初始化流量矩阵
        for (int i = 0; i < MAXN; i++)
            for (int j = 0; j < MAXN; j++)
                flow[i][j] = 0;

        // 读取每条边的信息，并初始化容量矩阵
        for (int i = 0; i < m; i++) {
            int u, v, cap;
            cin >> u >> v >> cap;
            u--; v--; // 调整为0-based索引
            capacity[u][v] = cap;
            flow[u][v] = 0;
        }

        // 设置源点和汇点
        int src = 0, dest = n - 1;
        // 计算并输出最大流
        cout << maxFlow(src, dest) << endl;
    }
}

//组员3 CI
namespace C
{
    //题目
    
    // 定义 S(x) = f(x) + g(x)  
    double S(double x, double a, double b) {
        return sqrt(x * x + a) + sqrt((b - x) * (b - x) + 1);
    }

    // 求 S(x) 的导数并找到最小值
    double findMin(double a, double b) {
        double left = 0.0;
        double right = b;
        double eps = 1e-7; // 精度 

        // 使用三分法查找最小值 
        while (right - left > eps) {
            double mid1 = left + (right - left) / 3;
            double mid2 = right - (right - left) / 3;
            if (S(mid1, a, b) < S(mid2, a, b)) {
                right = mid2; // mid1 更小，缩小右边界
            }
            else {
                left = mid1; // mid2 更小，缩小左边界 
            }
        }
        return S(left, a, b); // 返回最小值
    }
    void test()
    {
        double a, b;
        cin >> a >> b;

        //计算最小值并输出 
        double minValue = findMin(a, b);
        cout << fixed << setprecision(6) << minValue << endl;

    }
}
namespace I
{
    //题目
    /*现在科研人员有 n 个烧杯， t 毫升物质β，
        第 i 个烧杯中现在有 li 毫升物质α，若研制成功将得到 pi 毫升的新能源，而科研
        人员可以在烧杯中加入整数毫升的物质β，研制成功的概率为(物质β的量) / (物
            质α的量 + 物质β的量)。现在科研人员想要合理分配他们的物质β使得研制成功
        的新能源的量期望值最大，但是一个烧杯中的物质β不能超过物质α的量，否则
        会发生爆炸。现在烧杯中物质α的量将会发生 q 次变动，科研人员想要知道每次
        变动之后他们能获得的新能源的量的最大期望值。
        输入说明：
        第一行三个正整数： n, t, q
        第二行 n 个正整数： pi
        第三行 n 个正整数： li
        接下来的 q 行每行两个正整数： tj， rj。 tj 为 1 或 2， 1 表示增加 1 毫升物质
        α， 2 表示减少 1 毫升物质α， rj 为变动的烧杯编号。保证任意时刻所有烧杯不
        为空
        输出说明：
        q 行实数表示每次变动之后的答案
        如果绝对或相对误差不超过 1e-6，则答案将被视为正确。
        输入样例：
        2 1 3
        4 5
        1 2
        1 1
        1 2
        2 1
        输出样例：
        1.666666667
        1.333333333
        2.000000000*/
    #define MAX 100
    struct Container {
        double gain;
        int index;

        bool operator<(const Container& other) const {
            // 我们想要一个最大堆，所以根据增益进行比较（更大的增益应该在前）
            return gain < other.gain;
        }
    };

    double calculateExpectedValue(const vector<int>& p, const vector<int>& l, const vector<int>& b) {
        double total_E = 0.0;
        for (int i = 0; i < p.size(); ++i) {
            if (b[i] > 0) {
                total_E += (double(b[i]) / (l[i] + b[i])) * p[i];
            }
        }
        return total_E;
    }

    void allocateResources(int t, const vector<int>& p, const vector<int>& l, vector<int>& b) {
        priority_queue<Container> heap;
        for (int i = 0; i < p.size(); ++i) {
            if (l[i] > 0) {
                double gain = (double)p[i] / (l[i] + 1);
                heap.push({ gain, i });
            }
        }

        for (int j = 0; j < t; ++j) {
            if (heap.empty()) break;
            Container top = heap.top();
            heap.pop();
            int i = top.index;
            b[i]++;
            if (b[i] < l[i]) {
                double gain = p[i] * l[i] / pow(l[i] + b[i] + 1, 2);
                heap.push({ gain, i });
            }
        }
    }

    void test() {
        int n, t, q;
        cin >> n >> t >> q;
        vector<int> p(n), l(n);

        // 读取 p 和 l 数组
        for (int i = 0; i < n; ++i) {
            cin >> p[i];
        }
        for (int i = 0; i < n; ++i) {
            cin >> l[i];
        }

        // 分配初始资源
        vector<int> b(n, 0);
        allocateResources(t, p, l, b);

        // 输出初始预期值
        double total_E = calculateExpectedValue(p, l, b);

        double expectationM[MAX];
        // 处理查询
        for (int j = 0; j < q; ++j) {
            int tj, rj;
            cin >> tj >> rj;
            rj--;  // 索引从 0 开始

            // 根据查询更新 l[rj]
            if (tj == 1) {
                l[rj]++;
            }
            else if (tj == 2 && l[rj] > 0) {
                l[rj]--;
            }

            // 在每次查询后重新分配资源
            fill(b.begin(), b.end(), 0);  // 将分配项重置为零
            allocateResources(t, p, l, b);

            // 计算更新后的预期值
            total_E = calculateExpectedValue(p, l, b);
            expectationM[j] = total_E;
        }
        //输出最大期望值
        for (int i = 0; i < q; i++)
            cout << fixed << setprecision(9) << expectationM[i] << endl;

    }
}
//组员4 AG
namespace A
{
    //题目
   /* 第一年 H 市的植被覆盖数为 N 平方千米，当植被覆盖数达到 M 平方
        千米以下时，则说明当地已经严重污染，植被覆盖不足。假设 H 市的植被覆
        盖数每年以 K% 的减少。请问多少年之后 H 市将会严重污染？
        输入说明：一行包含三个整数 N, M, K（ 1, 2 1, 1 100 ≤ ≤ − ≤ < N M K 31 ） ，N 表
        示第一年 H 市的植被覆盖数, M 表示 M 平方千米以下时， 则说明当地已经严重
        污染，K 表示 H 市的植被覆盖数每年以 K% 的减少
        输出说明：输出一个整数，表示多少年之后 H 市将会严重污染*/
    //解决函数
    void test()
    {
        long long N, M, K;
        cout << "请按顺序输入N,M,K的值:" << endl;
        cin >> N >> M >> K;

        int years = 0;
        double remaining_vegetation;  // 使用 double 类型以保持精度
        remaining_vegetation = N;

        while (remaining_vegetation >= M) {
            remaining_vegetation *= (100.0 - K) / 100.0;  // 按百分比减少植被覆盖数
            years++;  // 年数增加
        }

        cout << years << endl;

    }
}
namespace G
{
    //题目
    /*今天无人机需要进行空中巡逻，需要找到无人机起
        飞 A 点和投送位置 B 点之间最短距离，同时避开保护装置的影响范围，保护装
        置可以看作为一个圆心为 C 点， 小于半径为 R 的实心球， A 点和 B 点不会在球内。
        通过解决这个问题，研究人员可以确保他们的北斗数据是准确和可靠的，这
        将帮助他们更好地了解保护区内动物生活习性。
        输入说明：
        前三行每行三个整数，表示 A、 B 和 C 点的坐标。保证坐标点都在（ - 1000，
        1000）
        第四行一个整数表示装置的半径 R。
        输出说明：
        输出 A 点到 B 的最小长度，精确到小数点后 2 位。
        输入样例：本科组试题册(2023)
        12 / 20
        0 0 12
        12 0 0
        10 0 10
        10*/
    const double eps = 1e-18;
    struct Point3
    {
        double x, y, z;
        Point3(double x = 0, double y = 0, double z = 0) : x(x), y(y), z(z) {}
    };
    typedef Point3 Vector3;

    Vector3 operator + (Vector3 A, Vector3 B) { return Vector3(A.x + B.x, A.y + B.y, A.z + B.z); }
    Vector3 operator - (Point3 A, Point3 B) { return Vector3(A.x - B.x, A.y - B.y, A.z - B.z); }

    int dcmp(double x) { if (fabs(x) < eps) return 0; else return x < 0 ? -1 : 1; }
    bool operator == (Point3 p1, Point3 p2)
    {
        return (dcmp(p1.x - p2.x) == 0) && (dcmp(p1.y - p2.y) == 0) && (dcmp(p1.z - p2.z) == 0);
    }
    double Dot(Vector3 A, Vector3 B) { return A.x * B.x + A.y * B.y + A.z * B.z; }     //三维点积 
    double Length(Vector3 A) { return sqrt(Dot(A, A)); }


    Vector3 Cross(Vector3 A, Vector3 B)
    {
        return Vector3(A.y * B.z - A.z * B.y, A.z * B.x - A.x * B.z, A.x * B.y - A.y * B.x);
    }

    double DistanceToSegment(Point3 P, Point3 A, Point3 B)
    {
        if (A == B) return Length(P - A);
        Vector3 v1 = B - A, v2 = P - A, v3 = P - B;
        if (dcmp(Dot(v1, v2)) < 0) return Length(v2);
        else if (dcmp(Dot(v1, v3)) > 0) return Length(v3);
        else return Length(Cross(v1, v2)) / Length(v1);
    }
    //综合解决函数
    void test()
    {
        {
            int xa, ya, za, xb, yb, zb, xc, yc, zc, r;
            cin >> xa >> ya >> za >> xb >> yb >> zb >> xc >> yc >> zc >> r;
            Point3 A(xa, ya, za), B(xb, yb, zb), C(xc, yc, zc);
            double d = DistanceToSegment(C, A, B);
            if (d >= r) {
                printf("%.2f", sqrt((xa - xc) * (xa - xc) + (ya - yc) * (ya - yc) + (za - zc) * (za - zc)) + sqrt((xb - xc) * (xb - xc) + (yb - yc) * (yb - yc) + (zb - zc) * (zb - zc)));
            }
            else {
                double d1 = (xa - xc) * (xa - xc) + (ya - yc) * (ya - yc) + (za - zc) * (za - zc) - r * r;
                double d2 = (xb - xc) * (xb - xc) + (yb - yc) * (yb - yc) + (zb - zc) * (zb - zc) - r * r;
                //cout<<d1+d2<<"\n";
                double cc = ((xc - xa) * (xc - xb) + (yc - ya) * (yc - yb) + (zc - za) * (zc - zb)) * 1.0 / (sqrt((xa - xc) * (xa - xc) + (ya - yc) * (ya - yc) + (za - zc) * (za - zc)) * sqrt((xb - xc) * (xb - xc) + (yb - yc) * (yb - yc) + (zb - zc) * (zb - zc)));
                double ccc = acos(cc);
                double dc = acos(r * 1.0 / sqrt((xa - xc) * (xa - xc) + (ya - yc) * (ya - yc) + (za - zc) * (za - zc))) + acos(r * 1.0 / sqrt((xb - xc) * (xb - xc) + (yb - yc) * (yb - yc) + (zb - zc) * (zb - zc)));
                double aa = ccc - dc;
                printf("%.2f", sqrt(d1) + sqrt(d2) + aa * r);
            }

        }
    }
}
int main() 
{      
    I::test();
    return 0;
}



